﻿//---------------------------------------
// Copyright (c) 2013-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------
using UnityEditor;

namespace EditorFramework
{
    public static class EditorUtility2
    {
        #region FormatBytes
        /// <summary>
        /// Gets a formatted text of the specified size in bytes.
        /// </summary>
        /// <remarks>
        /// This is pretty much the same as EditorUtility.FormatBytes, but this method
        /// is not limited to 32bit and thus can handle sizes more than 2 GB.
        /// </remarks>
        /// <param name="bytes">The size in bytes.</param>
        /// <returns>The text, eg. 100 Bytes, 78 KB, 18 MB or 97 GB.</returns>
        public static string FormatBytes(long bytes)
        {
            const float KiloByte   = 1024.0f;
            const float MegaByte   = 1024.0f * 1024;
            const double GigaByte  = 1024.0  * 1024 * 1024;
            const double TerraByte = 1024.0  * 1024 * 1024 * 1024;

            if (bytes < KiloByte)
                return string.Format("{0} Bytes", bytes);

            if (bytes < MegaByte)
                return string.Format("{0:F1} KB", bytes / KiloByte);

            if (bytes < GigaByte)
                return string.Format("{0:F1} MB", bytes / MegaByte);

            if (bytes < TerraByte)
                return string.Format("{0:F2} GB", bytes / GigaByte);

            return string.Format("{0:F2} TB", bytes / TerraByte);
        }
        #endregion

        #region UnloadUnusedAssetsImmediate
        /// <summary>
        /// Unloads assets that are not used.
        /// </summary>
        public static void UnloadUnusedAssetsImmediate()
        {
#if UNITY_5
            EditorUtility.UnloadUnusedAssetsImmediate();
#else
            EditorUtility.UnloadUnusedAssets();
#endif
        }
        #endregion
    }
}
