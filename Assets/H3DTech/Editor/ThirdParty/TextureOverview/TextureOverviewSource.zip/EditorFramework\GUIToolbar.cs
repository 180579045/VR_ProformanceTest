﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    #region GUIToolbar
    public class GUIToolbar : GUIControl
    {
        #region Private Fields
        List<GUIControl> _controls = new List<GUIControl>();
        #endregion

        #region ctor
        /// <summary>
        /// Initializes a new instance of the GUIToolbar class.
        /// </summary>
        /// <param name="editor">The EditorWindow where this control resides in.</param>
        /// <param name="parent">The parent container of the control or null when it's a top-level control.</param>
        public GUIToolbar(EditorWindow editor, GUIControl parent)
            : base(editor, parent)
        {
            Style = EditorStyles.toolbar;
            LayoutOptions = new[] { GUILayout.ExpandWidth(true) };
        }
        #endregion

        #region AddControl
        /// <summary>
        /// Adds the specified control to the toolbar.
        /// </summary>
        /// <param name="control">The instance of a GUIControl</param>
        public void AddControl(GUIControl control)
        {
            _controls.Add(control);
        }

        public T AddControl<T>(T control, string text, string tooltip, Texture2D image, GUIControlExecuteDelegate execute) where T : GUIControl
        {
            return AddControl<T>(control, text, tooltip, image, execute, null);
        }

        public T AddControl<T>(T control, string text, string tooltip, Texture2D image, GUIControlExecuteDelegate execute, GUIControlQueryStatusDelegate querystatus) where T : GUIControl
        {
            control.Text = text;
            control.Tooltip = tooltip;
            control.Image = image;
            control.Execute = execute;
            control.QueryStatus = querystatus;

            AddControl(control);
            return control;
        }
        #endregion

        #region AddButton
        /// <summary>
        /// Adds a button.
        /// </summary>
        public GUIToolbarButton AddButton(string text, string tooltip, Texture2D image, GUIControlExecuteDelegate execute)
        {
            return AddButton(text, tooltip, image, execute, null);
        }

        /// <summary>
        /// Adds a button.
        /// </summary>
        public GUIToolbarButton AddButton(string text, string tooltip, Texture2D image, GUIControlExecuteDelegate execute, GUIControlQueryStatusDelegate querystatus)
        {
            var control = new GUIToolbarButton(this);
            control.Style = EditorStyles.toolbarButton;
            AddControl(control, text, tooltip, image, execute, querystatus);
            return control;
        }
        #endregion

        #region AddToggle
        /// <summary>
        /// Adds a toggle button.
        /// </summary>
        public GUIToolbarToggle AddToggle(string text, string tooltip, Texture2D image, GUIControlExecuteDelegate execute)
        {
            return AddToggle(text, tooltip, image, execute, null);
        }

        /// <summary>
        /// Adds a toggle button.
        /// </summary>
        public GUIToolbarToggle AddToggle(string text, string tooltip, Texture2D image, GUIControlExecuteDelegate execute, GUIControlQueryStatusDelegate querystatus)
        {
            var control = new GUIToolbarToggle(this);
            control.Style = EditorStyles.toolbarButton;
            AddControl(control, text, tooltip, image, execute, querystatus);
            return control;
        }
        #endregion

        #region AddSearchField
        /// <summary>
        /// Adds a search field.
        /// </summary>
        public GUIToolbarSearchField AddSearchField(string text, string[] searchModes, GUIControlExecuteDelegate execute)
        {
            return AddSearchField(text, searchModes, execute, null);
        }

        /// <summary>
        /// Adds a search field.
        /// </summary>
        public GUIToolbarSearchField AddSearchField(string text, string[] searchModes, GUIControlExecuteDelegate execute, GUIControlQueryStatusDelegate querystatus)
        {
            var control = new GUIToolbarSearchField(this);
            control.SearchModes = searchModes;
            AddControl(control, text, "", null, execute, querystatus);
            return control;
        }
        #endregion

        #region AddTextField
        /// <summary>
        /// Adds a text field.
        /// </summary>
        public GUIToolbarTextField AddTextField(string text, string tooltip, GUIControlExecuteDelegate execute)
        {
            return AddTextField(text, tooltip, execute, null);
        }

        /// <summary>
        /// Adds a text field.
        /// </summary>
        public GUIToolbarTextField AddTextField(string text, string tooltip, GUIControlExecuteDelegate execute, GUIControlQueryStatusDelegate querystatus)
        {
            var control = new GUIToolbarTextField(this);
            AddControl(control, text, tooltip, null, execute, querystatus);
            return control;
        }
        #endregion

        #region AddSpace
        /// <summary>
        /// Adds space.
        /// </summary>
        public GUIToolbarSpace AddSpace(float space)
        {
            var control = new GUIToolbarSpace(this);
            control.Space = space;
            AddControl(control, "", "", null, null, null);
            return control;
        }
        #endregion

        #region AddFlexibleSpace
        /// <summary>
        /// Adds flexible space.
        /// </summary>
        public GUIToolbarFlexibleSpace AddFlexibleSpace()
        {
            var control = new GUIToolbarFlexibleSpace(this);
            AddControl(control, "", "", null, null, null);
            return control;
        }
        #endregion

        #region AddLabel
        /// <summary>
        /// Adds a label.
        /// </summary>
        public GUIToolbarLabel AddLabel()
        {
            return AddLabel("", "", null);
        }

        /// <summary>
        /// Adds a label.
        /// </summary>
        public GUIToolbarLabel AddLabel(string text)
        {
            return AddLabel(text, "", null);
        }

        /// <summary>
        /// Adds a label.
        /// </summary>
        public GUIToolbarLabel AddLabel(string text, string tooltip)
        {
            return AddLabel(text, tooltip, null);
        }

        /// <summary>
        /// Adds a label.
        /// </summary>
        public GUIToolbarLabel AddLabel(string text, string tooltip, GUIControlQueryStatusDelegate querystatus)
        {
            var control = new GUIToolbarLabel(this);
            AddControl(control, text, tooltip, null, null, querystatus);
            return control;
        }
        #endregion

        #region AddPopup
        /// <summary>
        /// Adds a popup button.
        /// </summary>
        public GUIToolbarPopup AddPopup(string text, string tooltip, GUIControlExecuteDelegate execute)
        {
            return AddPopup(text, tooltip, execute, null);
        }

        /// <summary>
        /// Adds a popup button.
        /// </summary>
        public GUIToolbarPopup AddPopup(string text, string tooltip, GUIControlExecuteDelegate execute, GUIControlQueryStatusDelegate querystatus)
        {
            var control = new GUIToolbarPopup(this);
            AddControl(control, text, tooltip, null, execute, querystatus);
            return control;
        }
        #endregion

        #region AddMenu
        /// <summary>
        /// Adds a popup menu.
        /// </summary>
        public GUIToolbarMenu AddMenu(string text, string tooltip, GUIControlExecuteDelegate execute)
        {
            return AddMenu(text, tooltip, execute, null);
        }

        /// <summary>
        /// Adds a popup menu.
        /// </summary>
        public GUIToolbarMenu AddMenu(string text, string tooltip, GUIControlExecuteDelegate execute, GUIControlQueryStatusDelegate querystatus)
        {
            var control = new GUIToolbarMenu(this);
            AddControl(control, text, tooltip, null, execute, querystatus);
            return control;
        }
        #endregion

        #region AddRadioGroup
        public GUIToolbarRadioGroup AddRadioGroup()
        {
            var group = new GUIToolbarRadioGroup(this);
            AddControl(group);
            return group;
        }
        #endregion

        #region DoGUI
        protected override void DoGUI()
        {
            var oldsize = EditorGUIUtility.GetIconSize();
            EditorGUIUtility.SetIconSize(ImageSize);

            GUILayout.BeginHorizontal(Style, LayoutOptions);
            foreach (var control in _controls)
            {
                EditorGUIUtility.SetIconSize(Vector2.Min(ImageSize, control.ImageSize));

                control.OnGUI();
            }

            GUILayout.Space(1); // without any space, the gui thinks it's free space and uses it for something else
            //GUILayout.Box(GUIContent2.Temp(Text, Image, Tooltip), Style);//, GUILayout.ExpandWidth(true));
            GUILayout.EndHorizontal();

            EditorGUIUtility.SetIconSize(oldsize);
        }
        #endregion
    }
    #endregion

    #region GUIToolbarRadioGroup
    public class GUIToolbarRadioGroup : GUIControl
    {
        List<GUIToolbarRadioControl> _controls = new List<GUIToolbarRadioControl>();

        public GUIToolbarRadioControl CheckedControl
        {
            get;
            private set;
        }

        public GUIToolbarRadioGroup(GUIToolbar toolbar)
            : base(toolbar.Editor, toolbar)
        {
        }

        public void OnCheckedControl(GUIToolbarRadioControl control)
        {
            CheckedControl = control;
        }

        public void AddControl(GUIToolbarRadioControl control, string text, string tooltip, Texture2D image, GUIControlExecuteDelegate execute, GUIControlQueryStatusDelegate querystatus)
        {
            control.Text = text;
            control.Tooltip = tooltip;
            control.Image = image;
            control.Execute = execute;
            control.QueryStatus = querystatus;

            _controls.Add(control);
        }

        public GUIToolbarRadioButton AddButton(string text, string tooltip, Texture2D image, GUIControlExecuteDelegate execute)
        {
            return AddButton(text, tooltip, image, execute, null);
        }

        public GUIToolbarRadioButton AddButton(string text, string tooltip, Texture2D image, GUIControlExecuteDelegate execute, GUIControlQueryStatusDelegate querystatus)
        {
            var control = new GUIToolbarRadioButton(this);
            control.Style = EditorStyles.toolbarButton;
            AddControl(control, text, tooltip, image, execute, querystatus);
            return control;
        }

        protected override void DoGUI()
        {
            var oldsize = EditorGUIUtility.GetIconSize();
            EditorGUIUtility.SetIconSize(ImageSize);

            foreach (var control in _controls)
            {
                EditorGUIUtility.SetIconSize(Vector2.Min(ImageSize, control.ImageSize));

                control.OnGUI();
            }

            EditorGUIUtility.SetIconSize(oldsize);
        }
    }
    #endregion

    #region GUIToolbarRadioControl
    public abstract class GUIToolbarRadioControl : GUIControl
    {
        public GUIToolbarRadioGroup RadioGroup
        {
            get;
            private set;
        }

        public GUIToolbarRadioControl(GUIToolbarRadioGroup group)
            : base(group.Editor, group)
        {
            RadioGroup = group;
        }
    }
    #endregion

    #region GUIToolbarRadioButton
    public class GUIToolbarRadioButton : GUIToolbarRadioControl
    {
        public GUIToolbarRadioButton(GUIToolbarRadioGroup group)
            : base(group)
        {
            Style = EditorStyles.toolbarButton;
        }

        protected override void DoGUI()
        {
            var content = GUIContent2.Temp(Text, Image, Tooltip);

            var isChecked = ReferenceEquals(RadioGroup.CheckedControl, this);
            var pressed = GUILayout.Toggle(isChecked, content, Style, LayoutOptions);
            if (pressed != isChecked && null != Execute)
            {
                RadioGroup.OnCheckedControl(this);
                Execute.Invoke(this);
            }
        }
    }
    #endregion

    #region GUIToolbarButton
    public class GUIToolbarButton : GUIControl
    {
        /// <summary>
        /// Initializes a new instance of the GUIToolbarButton class.
        /// </summary>
        /// <param name="toolbar">The toolbar control that the toolbar button is assigned to.</param>
        public GUIToolbarButton(GUIToolbar toolbar)
            : base(toolbar.Editor, toolbar)
        {
            Style = EditorStyles.toolbarButton;
        }

        protected override void DoGUI()
        {
            var content = GUIContent2.Temp(Text, Image, Tooltip);
            //float minwidth, maxwidth;
            //Style.CalcMinMaxWidth(content, out minwidth, out maxwidth);

            var pressed = GUILayout.Button(content, Style, LayoutOptions);//, GUILayout.MaxWidth(minwidth));
            if (pressed && null != Execute)
                Execute.Invoke(this);
        }
    }
    #endregion

    #region GUIToolbarToggle
    public class GUIToolbarToggle : GUIControl
    {
        /// <summary>
        /// Initializes a new instance of the GUIToolbarToggle class.
        /// </summary>
        /// <param name="toolbar">The toolbar control that the toolbar toggle is assigned to.</param>
        public GUIToolbarToggle(GUIToolbar toolbar)
            : base(toolbar.Editor, toolbar)
        {
            Style = EditorStyles.toolbarButton;
        }

        protected override void DoGUI()
        {
            var content = GUIContent2.Temp(Text, Image, Tooltip);
            //float minwidth, maxwidth;
            //Style.CalcMinMaxWidth(content, out minwidth, out maxwidth);

            var ischecked = (this.OnQueryStatus() & GUIControlStatus.Checked) != 0;
            var pressed = GUILayout.Toggle(ischecked, content, Style, LayoutOptions);//, GUILayout.MaxWidth(minwidth));
            if (pressed != ischecked && null != Execute)
                Execute.Invoke(this);
        }
    }
    #endregion

    #region GUIToolbarLabel
    public class GUIToolbarLabel : GUIControl
    {
        /// <summary>
        /// Initializes a new instance of the GUIToolbarLabel class.
        /// </summary>
        /// <param name="toolbar">The toolbar control that the toolbar label is assigned to.</param>
        public GUIToolbarLabel(GUIToolbar toolbar)
            : base(toolbar.Editor, toolbar)
        {
            Style = new GUIStyle(GUI.skin.label);
            Style.alignment = TextAnchor.MiddleLeft;
        }

        protected override void DoGUI()
        {
            var content = GUIContent2.Temp(Text, Image, Tooltip);
            //float minwidth, maxwidth;
            //Style.CalcMinMaxWidth(content, out minwidth, out maxwidth);

            GUILayout.Label(content, Style, LayoutOptions);//, GUILayout.MaxWidth(minwidth));
        }
    }
    #endregion

    #region GUIToolbarSpace
    public class GUIToolbarSpace : GUIControl
    {
        public float Space = 0;

        /// <summary>
        /// Initializes a new instance of the GUIToolbarSpace class.
        /// </summary>
        /// <param name="toolbar">The toolbar control that the toolbar space is assigned to.</param>
        public GUIToolbarSpace(GUIToolbar toolbar)
            : base(toolbar.Editor, toolbar)
        {
            Style = EditorStyles.toolbar;
        }

        protected override void DoGUI()
        {
            GUILayout.Space(Space);
        }
    }
    #endregion

    #region GUIToolbarFlexibleSpace
    public class GUIToolbarFlexibleSpace : GUIControl
    {
        /// <summary>
        /// Initializes a new instance of the GUIToolbarFlexibleSpace class.
        /// </summary>
        /// <param name="toolbar">The toolbar control that the toolbar flexible space is assigned to.</param>
        public GUIToolbarFlexibleSpace(GUIToolbar toolbar)
            : base(toolbar.Editor, toolbar)
        {
            Style = EditorStyles.toolbar;
        }

        protected override void DoGUI()
        {
            GUILayout.FlexibleSpace();
        }
    }
    #endregion

    #region GUIToolbarPopup
    public class GUIToolbarPopupItem
    {
        public GUIContent Text;
        public object Tag;

        public GUIToolbarPopupItem(string text)
        {
            this.Text = new GUIContent(text);
        }

        public GUIToolbarPopupItem(string text, object tag)
        {
            this.Text = new GUIContent(text);
            this.Tag = tag;
        }

        public override string ToString()
        {
            return Text.text;
        }
    }

    public class GUIToolbarPopup : GUIControl
    {
        GUIContent[] _items = new GUIContent[0];
        int _selectedindex = -1;
        GUIToolbarPopupItem _selectedItem;

        /// <summary>
        /// Gets or sets the selected popup item.
        /// If no item is selected, null is returned.
        /// </summary>
        public GUIToolbarPopupItem SelectedItem
        {
            get
            {
                return _selectedItem;
            }
            set
            {
                for (var n = 0; n < Items.Length; ++n)
                {
                    if (value == Items[n])
                    {
                        _selectedindex = n;
                        _selectedItem = value;
                        return;
                    }
                }

                _selectedItem = null;
                _selectedindex = -1;
            }
        }

        public GUIToolbarPopupItem[] Items = new GUIToolbarPopupItem[0];

        /// <summary>
        /// Initializes a new instance of the GUIToolbarPopup class.
        /// </summary>
        /// <param name="toolbar">The toolbar control that the toolbar popup is assigned to.</param>
        public GUIToolbarPopup(GUIToolbar toolbar)
            : base(toolbar.Editor, toolbar)
        {
            Style = EditorStyles.toolbarPopup;
        }

        protected override void DoGUI()
        {
            if (_items.Length != Items.Length)
            {
                _items = new GUIContent[Items.Length];
                for (var n = 0; n < Items.Length; ++n)
                    _items[n] = Items[n].Text;
            }

            float minwidth = float.MaxValue, maxwidth = float.MinValue;
            foreach (var item in _items)
            {
                float minitemwidth, maxitemwidth;
                Style.CalcMinMaxWidth(item, out minitemwidth, out maxitemwidth);
                minwidth = Mathf.Min(minwidth, minitemwidth);
                maxwidth = Mathf.Max(maxwidth, maxitemwidth);
            }

            var newindex = EditorGUILayout.Popup(_selectedindex, _items, Style, GUILayout.MinWidth(maxwidth), GUILayout.MaxWidth(maxwidth));
            if (newindex != _selectedindex)
            {
                _selectedindex = newindex;
                _selectedItem = Items[newindex];
                Text = _selectedItem.Text.text;

                if (null != Execute)
                    Execute.Invoke(this);
            }
        }

        public bool SelectTag(object tag)
        {
            for (var n = 0; n < Items.Length; ++n)
            {
                var item = Items[n];
                if (item.Tag != null && item.Tag.Equals(tag))
                {
                    SelectedItem = item;
                    return true;
                }
            }
            return false;
        }
    }
    #endregion

    #region GUIToolbarSearchField
    public class GUIToolbarSearchField : GUIControl
    {
        float _triggerTime = -1;

        /// <summary>
        /// The currently selected search mode.
        /// </summary>
        public int SearchMode;

        /// <summary>
        /// Names of available search modes.
        /// </summary>
        public string[] SearchModes;

        /// <summary>
        /// How many seconds have to elapse after the text changed, until the execute event gets fired.
        /// </summary>
        public float ExecDelay = 0.5f;

        /// <summary>
        /// Whether the control accepts drag&drop operations.
        /// </summary>
        public bool AcceptDrop;

        /// <summary>
        /// Initializes a new instance of the GUIToolbarSearchField class.
        /// </summary>
        /// <param name="toolbar">The toolbar control that the toolbar search field is assigned to.</param>
        public GUIToolbarSearchField(GUIToolbar toolbar)
            : base(toolbar.Editor, toolbar)
        {
            Style = EditorStyles.toolbarTextField;
            LayoutOptions = new[] { GUILayout.MaxWidth(250) };
        }

        protected override void DoGUI()
        {
            var rect = GUILayoutUtility.GetRect(GUIContent2.Temp(Text), Style, LayoutOptions);
            var oldmode = SearchMode;

            var newtext = EditorGUI2.ToolbarSearchField(rect, Text, SearchModes, ref SearchMode);

            // check for drag&drop
            var lastrect = GUILayoutUtility.GetLastRect();
            if (AcceptDrop && lastrect.Contains(Event.current.mousePosition) && DragAndDrop.paths != null && DragAndDrop.paths.Length > 0 && !string.IsNullOrEmpty(DragAndDrop.paths[0]))
            {
                if (Event.current.type == EventType.DragUpdated || Event.current.type == EventType.DragPerform)
                        DragAndDrop.visualMode = DragAndDropVisualMode.Copy;

                if (Event.current.type == EventType.DragPerform && DragAndDrop.paths != null)
                {
                    var paths = "";
                    foreach(var p in DragAndDrop.paths)
                    {
                        if (paths.Length > 0)
                            paths += " || "; // logical OR
                        paths += '\"' + p.Trim() + '\"'; // put paths in quotes, because they most likely contain spaces
                    }

                    newtext = paths;
                    DragAndDrop.AcceptDrag();
                    Editor.Repaint();
                }
            }

            // did the searchmode or text changed?
            if (oldmode != SearchMode || !string.Equals(newtext, Text, StringComparison.Ordinal))
            {
                if (_triggerTime < 0)
                    EditorApplication.update += OnEditorApplicationUpdate;

                Event.current.Use();
                Text = newtext;

                _triggerTime = Time.realtimeSinceStartup;
                if (!string.IsNullOrEmpty(Text) && oldmode == SearchMode)
                    _triggerTime += ExecDelay; // delay trigger when we have a search text
            }
        }

        void OnEditorApplicationUpdate()
        {
            if (_triggerTime > 0 && _triggerTime < Time.realtimeSinceStartup)
            {
                _triggerTime = -1;
                EditorApplication.update -= OnEditorApplicationUpdate;

                if (null != Execute)
                {
                    Execute.Invoke(this);
                    Editor.Repaint();
                }
            }
        }
    }
    #endregion

    #region GUIToolbarTextField
    public class GUIToolbarTextField : GUIControl
    {
        /// <summary>
        /// Initializes a new instance of the GUIToolbarTextField class.
        /// </summary>
        /// <param name="toolbar">The toolbar control that the toolbar text field is assigned to.</param>
        public GUIToolbarTextField(GUIToolbar toolbar)
            : base(toolbar.Editor, toolbar)
        {
            Style = EditorStyles.toolbarTextField;
        }

        protected override void DoGUI()
        {
            var newtext = EditorGUILayout.TextField(Text, LayoutOptions);
            if (!string.Equals(newtext, Text, StringComparison.Ordinal))
            {
                Text = newtext;
                if (null != Execute)
                    Execute.Invoke(this);
            }
        }
    }
    #endregion

    #region GUIToolbarSlider
    public class GUIToolbarSlider : GUIControl
    {
        float _value;

        /// <summary>
        /// The minimum value of the slider.
        /// </summary>
        public float MinValue
        {
            get;
            set;
        }

        /// <summary>
        /// The maximum value of the slider.
        /// </summary>
        public float MaxValue
        {
            get;
            set;
        }

        /// <summary>
        /// The current value of the slider, between MinValue and MaxValue.
        /// </summary>
        public float Value
        {
            get;
            set;
        }

        /// <summary>
        /// Initializes a new instance of the GUIToolbarSlider class.
        /// </summary>
        /// <param name="toolbar">The toolbar control that the toolbar slider is assigned to.</param>
        public GUIToolbarSlider(GUIToolbar toolbar, float minvalue, float maxvalue)
            : base(toolbar.Editor, toolbar)
        {
            Style = GUI.skin.horizontalSlider;
            LayoutOptions = new[] { GUILayout.MinWidth(64), GUILayout.MaxWidth(64) };
            MinValue = minvalue;
            MaxValue = maxvalue;
            Value = minvalue;
            _value = minvalue;
        }

        protected override void DoGUI()
        {
            var newvalue = GUILayout.HorizontalSlider(Value, MinValue, MaxValue, LayoutOptions);
            if (Mathf.Abs(newvalue - _value) > 0.001f)
            {
                Value = newvalue;
                if (null != Execute)
                    Execute.Invoke(this);
            }
            _value = newvalue;
        }
    }
    #endregion

    #region GUIToolbarMenuItem
    public class GUIToolbarMenuItem
    {
        public GUIContent Text;
        public Action<GUIToolbarMenuItem> Execute;
        public Func<GUIToolbarMenuItem, GUIControlStatus> QueryStatus;
        public object Tag;

        public GUIToolbarMenu Owner
        {
            get;
            internal set;
        }

        public bool IsChecked
        {
            get
            {
                if (QueryStatus == null || Owner == null)
                    return false;

                var status = QueryStatus(this);
                if ((status & GUIControlStatus.Checked) == 0)
                    return false;

                return true;
            }
        }

        public GUIToolbarMenuItem(string text)
        {
            this.Text = new GUIContent(text);
        }

        public GUIToolbarMenuItem(string text, Action<GUIToolbarMenuItem> exec)
            : this(text, exec, null)
        {
        }

        public GUIToolbarMenuItem(string text, Action<GUIToolbarMenuItem> exec, Func<GUIToolbarMenuItem, GUIControlStatus> query)
        {
            this.Text = new GUIContent(text);
            this.Execute = exec;
            this.QueryStatus = query;
        }

        public override string ToString()
        {
            return Text.text;
        }

        public static GUIToolbarMenuItem Separator
        {
            get
            {
                return new GUIToolbarMenuItem("-");
            }
        }
    }
    #endregion

    #region GUIToolbarMenu
    public class GUIToolbarMenu : GUIControl
    {
        GUIContent[] _items = new GUIContent[0];
        Rect _rect;

        public GUIToolbarMenuItem[] Items = new GUIToolbarMenuItem[0];

        public GUIToolbarMenu(GUIToolbar toolbar)
            : base(toolbar.Editor, toolbar)
        {
            Style = EditorStyles.toolbarDropDown;
        }

        public void Add(GUIToolbarMenuItem item)
        {
            if (item.Owner != null)
                throw new ArgumentException("'item' has been added to a toolbar already");

            var list = new List<GUIToolbarMenuItem>(Items);
            item.Owner = this;
            list.Add(item);
            Items = list.ToArray();
        }

        protected override void DoGUI()
        {
            CheckItemRebuild();

            var clicked = GUILayout.Button(GUIContent2.Temp(Text, Image, Tooltip), Style, LayoutOptions);
            if (Event.current.type == EventType.repaint)
            {
                _rect = GUILayoutUtility.GetLastRect();
                _rect.y += _rect.height;
                _rect.width = _rect.height = 0;
            }

            if (clicked)
            {
                if (Execute != null)
                {
                    Execute.Invoke(this);
                    CheckItemRebuild();
                }

                var menu = new GenericMenu();
                foreach (var item in Items)
                {
                    var status = GUIControlStatus.Visible | GUIControlStatus.Enable;
                    if (null != item.QueryStatus)
                        status = item.QueryStatus.Invoke(item);

                    if ((status & GUIControlStatus.Visible) == 0)
                        continue;

                    if (item.Text.text == "-")
                        menu.AddSeparator("");
                    else if ((status & GUIControlStatus.Enable) != 0 && item.Execute != null)
                        menu.AddItem(item.Text, (status & GUIControlStatus.Checked) != 0, OnMenu, item);
                    else
                        menu.AddItem(item.Text, (status & GUIControlStatus.Checked) != 0, null);
                }

                menu.DropDown(_rect);
            }
        }

        void CheckItemRebuild()
        {
            if (_items.Length != Items.Length)
            {
                _items = new GUIContent[Items.Length];
                for (var n = 0; n < Items.Length; ++n)
                    _items[n] = Items[n].Text;
            }
        }

        void OnMenu(object userdata)
        {
            var item = (GUIToolbarMenuItem)userdata;
            if (null != item && item.Execute != null)
                item.Execute.Invoke(item);
        }
    }
    #endregion
}
