﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    /// <summary>
    /// GUIStyles provides various GUI styles that are commonly needed.
    /// </summary>
    public static class GUIStyles
    {
        #region Private Fields
        // if you add a new style, do not forget to set its reference to null in OnPluginDestroy.
        static GUIStyle _whitestyle;
        static GUIStyle _revertButtonStyle;
        static GUIStyle _applyButtonStyle;
        static GUIStyle _nextButtonStyle;
        static GUIStyle _hyperlinkStyle;
        static GUIStyle _clear;
        static GUIStyle _cancelButtonStyle;
        static GUIStyle _tempImageStyle;
        static GUIStyle _labelRight;
        static GUIStyle _labelCenter;
        static GUIStyle _boldLabelRight;
        #endregion

        #region White
        public static GUIStyle White
        {
            get
            {
                if (null != _whitestyle)
                    return _whitestyle;

                _whitestyle = new GUIStyle(GUI.skin.label);
                _whitestyle.normal.textColor = Color.white;
                _whitestyle.normal.background = EditorGUIUtility.whiteTexture;
                _whitestyle.active.textColor = Color.white;
                _whitestyle.active.background = EditorGUIUtility.whiteTexture;
                _whitestyle.onActive.textColor = Color.white;
                _whitestyle.onActive.background = EditorGUIUtility.whiteTexture;
                _whitestyle.onFocused.textColor = Color.white;
                _whitestyle.onFocused.background = EditorGUIUtility.whiteTexture;
                _whitestyle.onHover.textColor = Color.white;
                _whitestyle.onHover.background = EditorGUIUtility.whiteTexture;
                _whitestyle.onNormal.textColor = Color.white;
                _whitestyle.onNormal.background = EditorGUIUtility.whiteTexture;
                _whitestyle.stretchHeight = true;
                _whitestyle.stretchWidth = true;
                _whitestyle.padding = new RectOffset();
                _whitestyle.margin = new RectOffset();
                _whitestyle.border = new RectOffset();

                return _whitestyle;
            }
        }
        #endregion

        #region Clear
        public static GUIStyle Clear
        {
            get
            {
                if (null != _clear)
                    return _clear;

                _clear = new GUIStyle(GUI.skin.label);
                _clear.normal.textColor = Color.clear;
                _clear.normal.background = null;
                _clear.active.textColor = Color.clear;
                _clear.active.background = null;
                _clear.onActive.textColor = Color.clear;
                _clear.onActive.background = null;
                _clear.onFocused.textColor = Color.clear;
                _clear.onFocused.background = null;
                _clear.onHover.textColor = Color.clear;
                _clear.onHover.background = null;
                _clear.onNormal.textColor = Color.clear;
                _clear.onNormal.background = null;
                _clear.stretchHeight = true;
                _clear.stretchWidth = true;
                _clear.padding = new RectOffset();
                _clear.margin = new RectOffset();
                _clear.border = new RectOffset();

                return _clear;
            }
        }
        #endregion

        #region Hyperlink
        public static GUIStyle Hyperlink
        {
            get
            {
                if (null != _hyperlinkStyle)
                    return _hyperlinkStyle;

                _hyperlinkStyle = new GUIStyle(EditorStyles.label);
                _hyperlinkStyle.wordWrap = true;
                _hyperlinkStyle.normal.textColor = GUIColors.Hyperlink;
                _hyperlinkStyle.onNormal.textColor = GUIColors.Hyperlink;
                _hyperlinkStyle.hover.textColor = GUIColors.Hyperlink;
                _hyperlinkStyle.onHover.textColor = GUIColors.Hyperlink;
                _hyperlinkStyle.active.textColor = GUIColors.Hyperlink;
                _hyperlinkStyle.onActive.textColor = GUIColors.Hyperlink;

                return _hyperlinkStyle;
            }
        }
        #endregion

        #region LabelRight
        /// <summary>
        /// Label with right aligned text rendering.
        /// </summary>
        public static GUIStyle LabelRight
        {
            get
            {
                if (null != _labelRight)
                    return _labelRight;

                _labelRight = new GUIStyle(EditorStyles.label);
                _labelRight.alignment = TextAnchor.UpperRight;

                return _labelRight;
            }
        }
        #endregion

        #region BoldLabelRight
        /// <summary>
        /// Label with a bold font and right aligned text rendering.
        /// </summary>
        public static GUIStyle BoldLabelRight
        {
            get
            {
                if (null != _boldLabelRight)
                    return _boldLabelRight;

                _boldLabelRight = new GUIStyle(EditorStyles.boldLabel);
                _boldLabelRight.alignment = TextAnchor.UpperRight;

                return _boldLabelRight;
            }
        }
        #endregion

        #region LabelCenter
        /// <summary>
        /// Label with center aligned text rendering.
        /// </summary>
        public static GUIStyle LabelCenter
        {
            get
            {
                if (null != _labelCenter)
                    return _labelCenter;

                _labelCenter = new GUIStyle(EditorStyles.label);
                _labelCenter.alignment = TextAnchor.UpperCenter;

                return _labelCenter;
            }
        }
        #endregion

        #region GetTempImageOnly
        public static GUIStyle GetTempImageOnly(Texture2D normal, Texture2D active)
        {

            if (null == _tempImageStyle)
            {
                _tempImageStyle = new GUIStyle(EditorStyles.toolbarButton);
                _tempImageStyle.margin = new RectOffset(0, 0, 0, 0);
                _tempImageStyle.contentOffset = new Vector2(0, 0);
                _tempImageStyle.border = new RectOffset(0, 0, 0, 0);
                _tempImageStyle.fixedHeight = 16;
                _tempImageStyle.fixedWidth = 16;
                _tempImageStyle.imagePosition = ImagePosition.ImageOnly;
                _tempImageStyle.padding = new RectOffset(0, 0, 0, 0);
            }

            _tempImageStyle.fixedHeight = normal.height;
            _tempImageStyle.fixedWidth = normal.width;
            _tempImageStyle.normal.background = normal;
            _tempImageStyle.active.background = active;
            return _tempImageStyle;
        }
        #endregion

        #region AcceptImageButton
        public static GUIStyle AcceptImageButton
        {
            get
            {
                if (null == _applyButtonStyle)
                {
                    _applyButtonStyle = new GUIStyle(EditorStyles.toolbarButton);
                    _applyButtonStyle.margin = new RectOffset(0, 0, 0, 0);
                    _applyButtonStyle.contentOffset = new Vector2(0, 0);
                    _applyButtonStyle.border = new RectOffset(0, 0, 0, 0);
                    _applyButtonStyle.fixedHeight = 16;
                    _applyButtonStyle.fixedWidth = 16;
                    _applyButtonStyle.imagePosition = ImagePosition.ImageOnly;
                    _applyButtonStyle.padding = new RectOffset(0, 0, 0, 0);
                }

                _applyButtonStyle.normal.background = Images.Accept16x16;
                _applyButtonStyle.active.background = Images.AcceptPressed16x16;

                return _applyButtonStyle;
            }
        }
        #endregion

        #region RevertImageButton
        public static GUIStyle RevertImageButton
        {
            get
            {
                if (_revertButtonStyle == null)
                {
                    _revertButtonStyle = new GUIStyle(EditorStyles.toolbarButton);
                    _revertButtonStyle.margin = new RectOffset(0, 0, 0, 0);
                    _revertButtonStyle.contentOffset = new Vector2(0, 0);
                    _revertButtonStyle.border = new RectOffset(0, 0, 0, 0);
                    _revertButtonStyle.fixedHeight = 16;
                    _revertButtonStyle.fixedWidth = 16;
                    _revertButtonStyle.imagePosition = ImagePosition.ImageOnly;
                    _revertButtonStyle.padding = new RectOffset(0, 0, 0, 0);
                }

                _revertButtonStyle.normal.background = Images.Revert16x16;
                _revertButtonStyle.active.background = Images.RevertPressed16x16;

                return _revertButtonStyle;
            }
        }
        #endregion

        #region NextImageButton
        public static GUIStyle NextImageButton
        {
            get
            {
                if (_nextButtonStyle == null)
                {
                    _nextButtonStyle = new GUIStyle(GUI.skin.label); // for some reason, if we don't use 'label', the image is blurry
                    _nextButtonStyle.margin = new RectOffset(0, 0, 0, 0);
                    _nextButtonStyle.contentOffset = new Vector2(0, 0);
                    _nextButtonStyle.border = new RectOffset(0, 0, 0, 0);
                    _nextButtonStyle.fixedHeight = 16;
                    _nextButtonStyle.fixedWidth = 16;
                    _nextButtonStyle.imagePosition = ImagePosition.ImageOnly;
                    _nextButtonStyle.padding = new RectOffset(0, 0, 0, 0);
                }

                _nextButtonStyle.normal.background = Images.Next16x16;
                _nextButtonStyle.active.background = Images.NextPressed16x16;

                return _nextButtonStyle;
            }
        }
        #endregion

        #region CancelImageButton
        public static GUIStyle CancelImageButton
        {
            get
            {
                if (null == _cancelButtonStyle)
                {
                    _cancelButtonStyle = new GUIStyle(EditorStyles.label);
                    _cancelButtonStyle.margin = new RectOffset(0, 0, 4, 0);
                    _cancelButtonStyle.contentOffset = new Vector2(0, 0);
                    _cancelButtonStyle.border = new RectOffset(0, 0, 0, 0);
                    _cancelButtonStyle.fixedHeight = 11;
                    _cancelButtonStyle.fixedWidth = 11;
                    _cancelButtonStyle.imagePosition = ImagePosition.ImageOnly;
                    _cancelButtonStyle.padding = new RectOffset(0, 0, 0, 0);
                }

                _cancelButtonStyle.normal.background = Images.Cancel16x16;
                _cancelButtonStyle.active.background = Images.CancelPressed16x16;

                return _cancelButtonStyle;
            }
        }
        #endregion
    }
}
