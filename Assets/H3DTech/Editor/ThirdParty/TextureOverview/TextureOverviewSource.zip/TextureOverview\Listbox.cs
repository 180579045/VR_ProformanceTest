﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEditor;
using EditorFramework;

namespace TextureOverview
{
    /// <summary>
    /// Listbox represents the control that displays texture settings.
    /// </summary>
    public class Listbox : GUIListView, IDisposable
    {
        #region class Column
        /// <summary>
        /// The Column class represents one column in the list header.
        /// </summary>
        class Column : GUIListViewColumn
        {
            public delegate void ColumnDrawer(Model model, GUIListViewDrawItemArgs args);
            public delegate int CompareDelegate2(Model x, Model y);
            public delegate string ExportDelegate(Model model);

            /// <summary>
            /// Occurs when the model gets drawn.
            /// </summary>
            public ColumnDrawer Drawer;

            /// <summary>
            /// Occurs when the column gets sorted.
            /// </summary>
            public CompareDelegate2 Comparer;

            /// <summary>
            /// Occurs when the column gets a request to get the item value as text.
            /// </summary>
            public ExportDelegate Exporter;

            /// <summary>
            /// Initializes a new instance of the Column class.
            /// </summary>
            public Column(string serializeName, string text, string tooltip, float width, ColumnDrawer drawer, CompareDelegate2 comparer, ExportDelegate exporter)
                : base(text, tooltip, null, width, null)
            {
                base.SerializeName = serializeName;
                this.Drawer = drawer;
                this.Comparer = comparer;
                this.Exporter = exporter;

                // detour the base comparer callback to our CompareFuncImpl method
                if (null != comparer)
                    this.CompareFunc = CompareFuncImpl;
            }

            int CompareFuncImpl(object x, object y)
            {
                return this.Comparer(x as Model, y as Model);
            }
        }
        #endregion

        #region class Model
        /// <summary>
        /// The Model class represents an item within the list.
        /// </summary>
        /// <remarks>
        /// To display a certain value, we usually need its string representation.
        /// To avoid garbage generation while the plugin is running, we make this conversion during initialization only,
        /// the first time the value gets requested.
        /// </remarks>
        class Model : ICacheFileEntry
        {
            #region Private Fields
            // use en-US for formatting numbers, because we want to have 1.2 rather than 1,2 even in german language
            static System.Globalization.CultureInfo _enusCulture = System.Globalization.CultureInfo.GetCultureInfo("en-US");

            // when the model moves into view (it becomes visible inside the list), the asset preview
            // icon gets allocated. when it moves out of view, it gets released again.
            Texture _assetPreview;
            #endregion

            #region AssetGuid
            /// <summary>
            /// The GUID of the asset that belongs to this Model entry.
            /// </summary>
            public string AssetGuid;
            #endregion

            #region AssetTimestamp
            /// <summary>
            /// The timestamp when the asset has been modified/imported last.
            /// </summary>
            public ulong AssetTimestamp;
            #endregion

            #region HasError
            /// <summary>
            /// Whether an error occured while reading texture settings.
            /// </summary>
            public bool HasError;
            #endregion

            #region AssetPath
            string _assetPath;
            /// <summary>
            /// The asset path that belongs to this Model entry.
            /// </summary>
            /// <remarks>
            /// In order to get the AssetPath, AssetGuid must have been assigned first.
            /// </remarks>
            public string AssetPath
            {
                get
                {
                    if (null == _assetPath)
                        _assetPath = AssetDatabase.GUIDToAssetPath(AssetGuid) ?? "";
                    return _assetPath;
                }
            }
            #endregion

            #region FileExtension
            string _fileExtension;
            public string FileExtension
            {
                get
                {
                    if (null == _fileExtension)
                        _fileExtension = FileUtil2.GetFileExtension(AssetPath);
                    return _fileExtension;
                }
            }
            #endregion

            #region AssetName
            string _assetName;
            public string AssetName
            {
                get
                {
                    if (null == _assetName)
                        _assetName = FileUtil2.GetFileNameWithoutExtension(AssetPath);
                    return _assetName;
                }
            }
            #endregion

            #region MaxTextureSize
            public int MaxTextureSize;
            string _maxTextureSizeString;
            public string MaxTextureSizeString
            {
                get
                {
                    if (null == _maxTextureSizeString)
                        _maxTextureSizeString = MaxTextureSize.ToString();
                    return _maxTextureSizeString;
                }
            }
            #endregion

            #region Width
            string _widthString;
            public int Width;
            public string WidthString
            {
                get
                {
                    if (null == _widthString)
                        _widthString = Width.ToString();
                    return _widthString;
                }
            }
            #endregion
            
            #region Height
            public int Height;
            string _heightString;
            public string HeightString
            {
                get
                {
                    if (null == _heightString)
                        _heightString = Height.ToString();
                    return _heightString;
                }
            }
            #endregion

            #region OrgWidth
            public int OrgWidth;
            string _orgWidthString;
            public string OrgWidthString
            {
                get
                {
                    if (null == _orgWidthString)
                        _orgWidthString = OrgWidth.ToString();
                    return _orgWidthString;
                }
            }
            #endregion

            #region OrgHeight
            public int OrgHeight;
            string _orgHeightString;
            public string OrgHeightString
            {
                get
                {
                    if (null == _orgHeightString)
                        _orgHeightString = OrgHeight.ToString();
                    return _orgHeightString;
                }
            }
            #endregion

            #region AnisoLevel
            public int AnisoLevel;
            string _anisoLevelString;
            public string AnisoLevelString
            {
                get
                {
                    if (null == _anisoLevelString)
                        _anisoLevelString = AnisoLevel.ToString();
                    return _anisoLevelString;
                }
            }
            #endregion

            #region RuntimeSize
            public int RuntimeSize;
            string _runtimeSizeString;
            public string RuntimeSizeString
            {
                get
                {
                    if (null == _runtimeSizeString)
                        _runtimeSizeString = EditorUtility2.FormatBytes(RuntimeSize);
                    return _runtimeSizeString;
                }
            }

            public void RecalcMemoryUsage()
            {
                // Clear cached strings, so on the next access they get recreated with the new sizes
                _gpuSizeString = null;
                _cpuSizeString = null;
                _runtimeSizeString = null;

                // Get memory size for specified format
                var format = (TextureFormat)TextureFormat;
                var memusage = TextureUtil2.GetRuntimeMemorySize(format, Width, Height, MipmapCount > 1, IsReadable, IsCubemap);
                GpuSize = memusage.Gpu;
                CpuSize = memusage.Cpu;

                // Check if we want to expand rgb24 to rgba32 for gpu memory calculation
                if (format == UnityEngine.TextureFormat.RGB24 && Globals.GpuExpandRgb24ToRgba32)
                {
                    memusage = TextureUtil2.GetRuntimeMemorySize(UnityEngine.TextureFormat.RGBA32, Width, Height, MipmapCount > 1, IsReadable, IsCubemap);
                    GpuSize = memusage.Gpu;
                }

                RuntimeSize = GpuSize + CpuSize;
            }
            #endregion

            #region MainMemory Size
            /// <summary>
            /// How much memory the texture consumes in RAM.
            /// Texture needs to be Read/Write Enabled=true to add to RAM.
            /// </summary>
            public int CpuSize;

            string _cpuSizeString;
            public string CpuSizeString
            {
                get
                {
                    if (null == _cpuSizeString)
                        _cpuSizeString = EditorUtility2.FormatBytes(CpuSize);
                    return _cpuSizeString;
                }
            }
            #endregion


            #region Graphics Memory Size
            /// <summary>
            /// How much memory the texture consumes in graphics memory,
            /// when strictly considering the texture format (such as handling rgb24 as rgb24)
            /// </summary>
            public int GpuSize;

            string _gpuSizeString;
            public string GpuSizeString
            {
                get
                {
                    if (null == _gpuSizeString)
                        _gpuSizeString = EditorUtility2.FormatBytes(GpuSize);
                    return _gpuSizeString;
                }
            }
            #endregion

            #region StorageSize
            public int StorageSize;
            string _storageSizeString;
            public string StorageSizeString
            {
                get
                {
                    if (null == _storageSizeString)
                        _storageSizeString = EditorUtility2.FormatBytes(StorageSize);
                    return _storageSizeString;
                }
            }
            #endregion

            #region MipmapCount
            public int MipmapCount;
            string _mipmapCountString;
            public string MipmapCountString
            {
                get
                {
                    if (null == _mipmapCountString)
                        _mipmapCountString = MipmapCount.ToString();
                    return _mipmapCountString;
                }
            }
            #endregion

            #region WrapMode
            public int WrapMode;
            string _wrapModeString;
            public string WrapModeString
            {
                get
                {
                    if (null == _wrapModeString)
                        _wrapModeString = ((TextureWrapMode)WrapMode).ToString();
                    return _wrapModeString;
                }
            }
            #endregion

            #region FilterMode
            public int FilterMode;
            string _filterModeString;
            public string FilterModeString
            {
                get
                {
                    if (null == _filterModeString)
                        _filterModeString = ((UnityEngine.FilterMode)FilterMode).ToString();
                    return _filterModeString;
                }
            }
            #endregion

            #region TextureFormat
            public int TextureFormat;
            string _textureFormatString;
            public string TextureFormatString
            {
                get
                {
                    if (null == _textureFormatString)
                        _textureFormatString = TextureUtil2.GetTextureFormatString((TextureFormat)TextureFormat, (TextureUtil2.TextureType)TextureType);
                    return _textureFormatString;
                }
            }

            string _textureFormatShortString;
            public string TextureFormatShortString
            {
                get
                {
                    if (null == _textureFormatShortString)
                        _textureFormatShortString = TextureUtil2.GetTextureFormatShortString((TextureFormat)TextureFormat);
                    return _textureFormatShortString;
                }
            }
            #endregion

            #region TextureType
            public int TextureType;
            string _textureTypeString;
            public string TextureTypeString
            {
                get
                {
                    if (null == _textureTypeString)
                        _textureTypeString = TextureUtil2.GetTextureTypeString((TextureUtil2.TextureType)TextureType);
                    return _textureTypeString;
                }
            }
            #endregion

            #region IsCubemap
            public bool IsCubemap
            {
                get
                {
                    switch ((TextureUtil2.TextureType)TextureType)
                    {
                        case TextureUtil2.TextureType.Cubemap:
                        case TextureUtil2.TextureType.Reflection:
                            return true;
                    }
                    return false;
                }
            }
            #endregion

            public bool HasAlpha;
            public bool IsPowerOfTwo;

            #region IsReadable
            /// <summary>
            /// Corresponds to the 'Read/Write Enabled' setting in the Texture Inspector.
            /// </summary>
            public bool IsReadable;
            #endregion

            #region IsLinearSampling
            /// <summary>
            /// Corresponds to the 'Bypass sRGB Sampling' setting in the Texture Inspector.
            /// </summary>
            public bool IsLinearSampling;
            #endregion

            #region PixelRatio
            public float PixelRatio;
            string _pixelRatioString;
            public string PixelRatioString
            {
                get
                {
                    if (null == _pixelRatioString)
                        _pixelRatioString = string.Format("1/{0:F0}", PixelRatio);
                    return _pixelRatioString;
                }
            }
            #endregion

            #region PixelRatioTooltip
            string _pixelRatioTooltip;
            public string PixelRatioTooltip
            {
                get
                {
                    if (null == _pixelRatioTooltip)
                    {
                        if (Mathf.Abs(PixelRatioPercentage - 100) > 0.0001f)
                            _pixelRatioTooltip = string.Format("'{4}' resized from {0}x{1} to {2}x{3}", OrgWidth, OrgHeight, Width, Height, AssetName);
                        else
                            _pixelRatioTooltip = "";
                    }
                    return _pixelRatioTooltip;
                }
            }
            #endregion

            #region PixelRatioPercentage
            public float PixelRatioPercentage;
            string _pixelRatioPercentageString;
            public string PixelRatioPercentageString
            {
                get
                {
                    if (null == _pixelRatioPercentageString)
                        _pixelRatioPercentageString = string.Format(_enusCulture, "{0:F1}%", PixelRatioPercentage); // use culture because we want a dot/point as fractional-separator (german for example uses a comma) but different formats usually make import in various applications more difficult
                    return _pixelRatioPercentageString;
                }
            }
            #endregion

            #region CompressionQuality
            public int CompressionQuality;
            string _compressionQualityString;
            public string CompressionQualityString
            {
                get
                {
                    if (null == _compressionQualityString)
                    {
                        if (CompressionQuality < 0)
                            _compressionQualityString = ""; // not compressed
                        else
                        {
                            switch (CompressionQuality)
                            {
                                case 0: _compressionQualityString = "Fast"; break;
                                case 50: _compressionQualityString = "Normal"; break;
                                case 100: _compressionQualityString = "Best"; break;
                                default:
                                    _compressionQualityString = string.Format("{0}%", CompressionQuality);
                                    break;
                            }
                        }
                    }
                    return _compressionQualityString;
                }
            }
            #endregion

            #region SpriteImportMode
            public SpriteImportMode SpriteImportMode = SpriteImportMode.None;
            string _spriteImportModeString;
            public string SpriteImportModeString
            {
                get
                {
                    if (null == _spriteImportModeString)
                        _spriteImportModeString = SpriteImportMode.ToString();
                    return _spriteImportModeString;
                }
            }
            #endregion

            public string SpritePackingTag = "";

            #region SpritePixelToUnit
            public float SpritePixelPerUnit;
            string _spritePixelToUnitString;
            public string SpritePixelPerUnitString
            {
                get
                {
                    if (null == _spritePixelToUnitString)
                        _spritePixelToUnitString = string.Format("{0:F2}", SpritePixelPerUnit);
                    return _spritePixelToUnitString;
                }
            }
            #endregion

            #region ICacheFileEntry Implementation
            public string GetAssetGuid()
            {
                return AssetGuid;
            }

            public ulong GetAssetTimestamp()
            {
                return AssetTimestamp;
            }

            public void Serialize(BinarySerializer data)
            {
                data.Serialize(ref AssetGuid);
                data.Serialize(ref AssetTimestamp);
                data.Serialize(ref HasError);
                data.Serialize(ref MaxTextureSize);
                data.Serialize(ref Width);
                data.Serialize(ref Height);
                data.Serialize(ref OrgWidth);
                data.Serialize(ref OrgHeight);
                data.Serialize(ref AnisoLevel);
                data.Serialize(ref RuntimeSize); // RuntimeSize isn't actually needed to serialize anymore, because it is computed onthefly now. but we keep the old datalayout to be backwards compatible with existing cache files.
                data.Serialize(ref StorageSize);
                data.Serialize(ref MipmapCount);
                data.Serialize(ref WrapMode);
                data.Serialize(ref FilterMode);
                data.Serialize(ref TextureFormat);
                data.Serialize(ref TextureType);
                data.Serialize(ref HasAlpha);
                data.Serialize(ref IsPowerOfTwo);
                data.Serialize(ref IsReadable);
                data.Serialize(ref PixelRatio);
                data.Serialize(ref PixelRatioPercentage);
                data.Serialize(ref CompressionQuality);
                data.Serialize(ref IsLinearSampling);
                data.SerializeEnum<SpriteImportMode>(ref SpriteImportMode);
                data.Serialize(ref SpritePackingTag);
                data.Serialize(ref SpritePixelPerUnit);

                if (data.IsReader)
                {
                    RecalcMemoryUsage();
                }
            }
            #endregion

            #region Preview Image
            /// <summary>
            /// Gets the small image preview for the texture.
            /// </summary>
            public Texture GetSmallImage()
            {
                if (null != _assetPreview)
                    return _assetPreview;

                _assetPreview = UnityEditor.AssetDatabase.GetCachedIcon(AssetPath);
                if (null == _assetPreview && AssetDatabase2.IsAssetType(AssetPath, typeof(Cubemap)))
                    _assetPreview = Images.Cubemap16x16;

                if (null == _assetPreview)
                    _assetPreview = Images.Texture2D16x16;

                return _assetPreview;
            }

            /// <summary>
            /// Clears the image preview. Call this when the model goes out of view in the list.
            /// </summary>
            public void ClearSmallImage()
            {
                _assetPreview = null;
            }
            #endregion

            #region Init
            /// <summary>
            /// Initializes the model for the texture of the specified path and platform.
            /// </summary>
            /// <param name="path">The full path to the texture.</param>
            /// <param name="platform">The platform from which to read the settings.</param>
            public void Init(string path, string platform)
            {
                _assetPath = null;
                _assetName = null;
                _fileExtension = null;
                _maxTextureSizeString = null;
                _widthString = null;
                _heightString = null;
                _orgWidthString = null;
                _orgHeightString = null;
                _anisoLevelString = null;
                _runtimeSizeString = null;
                _cpuSizeString = null;
                _gpuSizeString = null;
                _storageSizeString = null;
                _mipmapCountString = null;
                _wrapModeString = null;
                _filterModeString = null;
                _pixelRatioString = null;
                _pixelRatioTooltip = null;
                _pixelRatioPercentageString = null;
                _textureTypeString = null;
                _textureFormatString = null;
                _textureFormatShortString = null;
                _compressionQualityString = null;
                _assetPreview = null;
                _spriteImportModeString = null;
                _spritePixelToUnitString = null;
                HasError = false;

                AssetGuid = AssetDatabase.AssetPathToGUID(path);

                var importer = AssetImporter.GetAtPath(path);
                var textureImporter = importer as TextureImporter;

                AssetTimestamp = importer != null ? importer.assetTimeStamp : 0;

                var platformsetting = TextureImporter2.GetTexturePlatformSetting(textureImporter, platform);
                var Asset = AssetDatabase.LoadAssetAtPath(path, typeof(Texture)) as Texture;
                if (null == Asset)
                    HasError = true;

                Width = Asset != null ? Asset.width : -1;
                Height = Asset != null ? Asset.height : -1;
                
                TextureUtil2.GetOriginalWidthAndHeight(Asset, textureImporter, out OrgWidth, out OrgHeight);
                PixelRatioPercentage = 100 * ((Width * Height) / (float)(OrgWidth * OrgHeight));
                PixelRatio = 1 / ((Width * Height) / (float)(OrgWidth * OrgHeight));
                AnisoLevel = Asset != null ? Asset.anisoLevel : -1;
                StorageSize = Asset != null ? TextureUtil2.GetStorageMemorySize(Asset) : -1;
                MipmapCount = Asset != null ? TextureUtil2.GetMipmapCount(Asset) : -1;
                WrapMode = Asset != null ? (int)Asset.wrapMode : -1;
                FilterMode = Asset != null ? (int)Asset.filterMode : -1;
                
                TextureType = (int)TextureUtil2.GetTextureType(Asset, textureImporter);
                TextureFormat = Asset != null ? (int)TextureUtil2.GetTextureFormat(Asset) : -1;

                CompressionQuality = -1;
                if (TextureUtil2.IsCompressedTextureFormat((TextureFormat)TextureFormat))
                    CompressionQuality = platformsetting != null ? platformsetting.CompressionQuality : -1;

                HasAlpha =  Asset != null ? TextureUtil2.HasAlpha(Asset) : false;
                if (TextureImporter2.IsNormalMap(textureImporter))
                    HasAlpha = false;

                IsPowerOfTwo = Asset != null ? TextureUtil2.IsPowerOfTwo(Asset) : false;
                IsReadable = (Asset != null && textureImporter != null) ? TextureUtil2.IsReadable(Asset, textureImporter) : false;
                IsLinearSampling = textureImporter != null ? textureImporter.linearTexture : false;

                MaxTextureSize = platformsetting != null ? platformsetting.MaxTextureSize : -1;
                if (IsCubemap)
                    MaxTextureSize = Mathf.Max(OrgWidth, OrgHeight);

                SpriteImportMode = UnityEditor.SpriteImportMode.None;
                SpritePackingTag = "";
                SpritePixelPerUnit = -1;
                if (textureImporter != null && textureImporter.spriteImportMode != UnityEditor.SpriteImportMode.None)
                {
                    SpriteImportMode = textureImporter.spriteImportMode;
                    SpritePackingTag = textureImporter.spritePackingTag;
#if UNITY_5
                    SpritePixelPerUnit = textureImporter.spritePixelsPerUnit;
#else
                    SpritePixelPerUnit = textureImporter.spritePixelsToUnits;
#endif
                }

                RecalcMemoryUsage();
            }
            #endregion
        }
        #endregion

        #region Private Fields
        CacheFile<Model> _cache = new CacheFile<Model>(13, Globals.ProductTitle, "TextureOverview");
        List<Model> _items = new List<Model>();
        List<Model> _allitems = new List<Model>();
        string _platform = "Default";
        bool _disposed;
        List<string> _typeFilter = new List<string>();
        SearchTextParser.Result _filterResult = new SearchTextParser.Result();
        TextFilterMode _filterMode;
        int _filterUpdateCount;
        Dictionary<string, string> _typeFilterDict = new Dictionary<string, string>();
        #endregion

        /// <summary>
        /// The TextFilterMode indicates which property the search function considers for text matching.
        /// </summary>
        public enum TextFilterMode
        {
            Name = 0,
            Path = 1
        }

        /// <summary>
        /// The active build target platform group.
        /// </summary>
        public BuildTargetGroup PlatformGroup;

        /// <summary>
        /// The active build target platform group name, such as 'Standalone', 'Android', etc.
        /// </summary>
        public string Platform
        {
            get
            {
                return _platform;
            }
            set
            {
                if (_platform != value)
                {
                    _platform = value;
                    Editor.Repaint();
                }
            }
        }

        /// <summary>
        /// Event is raised whenever the listbox content changed,
        /// eg caused by search operation.
        /// </summary>
        public Action<Listbox> Changed;

        /// <summary>
        /// Event is raised whenever a texture changed,
        /// </summary>
        public Action<Listbox> TextureChanged;

        /// <summary>
        /// Gets the number of items currently in the list.
        /// </summary>
        public int ItemCount
        {
            get
            {
                return _items.Count;
            }
        }

        /// <summary>
        /// Gets a string describing how many items are in the list.
        /// </summary>
        public string ItemCountString
        {
            get
            {
                if (_items.Count != _allitems.Count)
                    return string.Format("{0}/{1} Textures", _items.Count, _allitems.Count);
                return string.Format("{0} Textures", _items.Count);
            }
        }

        /// <summary>
        /// Indicates at which time the UnityEditor.Selection has been assigned.
        /// </summary>
        /// <remarks>
        /// If the user double-clicks an item in AudioClip Explorer, we assign it to UnityEditor.Selection.
        /// But on the same hand, AudioClip Explorer can listen to selection changes in Unity to automatically
        /// display the selected items. To avoid that 'feedback loop', we assign the time to this variable
        /// when the user double-clicks an item in the list and the selection change listening code can check
        /// if the selection change came from this list.
        /// </remarks>
        public double ChangeUnitySelectionTime
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets a string describing the selected items in the list.
        /// </summary>
        public string SelectionString
        {
            get
            {
                if (SelectedItemsCount == 0)
                    return ""; // no selection, no text

                var models = GetSelectedModels();
                if (SelectedItemsCount == 1)
                    return models[0].AssetPath;

                // sum the sizes of all selected models
                long storagesize = 0;
                long runtimesize = 0;
                foreach (var model in models)
                {
                    storagesize += model.StorageSize;
                    runtimesize += model.RuntimeSize;
                }

                return string.Format("{0} selected | Storage: {1} | Runtime: {2}",
                    models.Count,
                    EditorUtility2.FormatBytes(storagesize),
                    EditorUtility2.FormatBytes(runtimesize));
            }
        }

        #region ctor
        /// <summary>
        /// Initializes a new instance of the Listbox class.
        /// </summary>
        /// <param name="editor">The EditorWindow where this control resides in.</param>
        /// <param name="parent">The parent container of the control or null when it's a top-level control.</param>
        public Listbox(EditorWindow editor, GUIControl parent)
            : base(editor, parent)
        {
            HeaderStyle = GUIListViewHeaderStyle.ClickablePopup;
            MultiSelect = true;
            DragDropEnabled = true;
            RightClickSelect = true;
            Mode = GUIListViewMode.Details;
            ItemSize = new Vector2(0, 22);
            FullRowSelect = true;

            // add columns to the listbox
            Columns.Add(new Column("Name", "Name", "Asset Name", 220, OnDrawAssetName, OnCompareAssetName, OnExportAssetName));
            Columns.Add(new Column("Path", "Path", "Asset Path", 220, OnDrawAssetPath, OnCompareAssetPath, OnExportAssetPath) { Visible = false });
            Columns.Add(new Column("Type", "Type", "Texture Type setting. Indicates for what the texture will be used for.", 80, OnDrawImportType, OnCompareImportType, OnExportImportType));
            Columns.Add(new Column("StorageSize", "Storage Size", "How many space the asset consumes on the storage system (disk) when uncompressed.", 80, OnDrawStorageSize, OnCompareStorageSize, OnExportStorageSize));
            Columns.Add(new Column("RuntimeSize", "Runtime Size", "How many space the asset consumes in memory (graphics + main memory).", 85, OnDrawRuntimeSize, OnCompareRuntimeSize, OnExportRuntimeSize));
            Columns.Add(new Column("CpuSize", "Main Memory", "How many space the texture consumes in main memory. Only applies to textures that use Read/Write Enabled.", 85, OnDrawCpuSize, OnCompareCpuSize, OnExportCpuSize));
            Columns.Add(new Column("GpuSize", "Graphics Memory", "How many space the texture consumes in graphics memory.", 85, OnDrawGpuSize, OnCompareGpuSize, OnExportGpuSize));
            Columns.Add(new Column("SourceWidth", "Source Width", "Width in pixels of source texture.", 40, OnDrawOriginalWidth, OnCompareOriginalWidth, OnExportOriginalWidth));
            Columns.Add(new Column("SourceHeight", "Source Height", "Height in pixels of source texture.", 40, OnDrawOriginalHeight, OnCompareOriginalHeight, OnExportOriginalHeight));
            Columns.Add(new Column("MaxSize", "Max Size", "Maximum Texture Size in pixels.", 60, OnDrawMaxSize, OnCompareMaxSize, OnExportMaxSize));
            Columns.Add(new Column("Width", "Width", "Texture Width in pixels.", 45, OnDrawWidth, OnCompareWidth, OnExportWidth));
            Columns.Add(new Column("Height", "Height", "Texture Height in pixels.", 45, OnDrawHeight, OnCompareHeight, OnExportHeight));
            Columns.Add(new Column("Wrap", "Wrap", "Texture Wrap Mode.", 60, OnDrawWrapMode, OnCompareWrapMode, OnExportWrapMode));
            Columns.Add(new Column("Filter", "Filter", "Texture Filter Mode.", 60, OnDrawFilterMode, OnCompareFilterMode, OnExportFilterMode));
            Columns.Add(new Column("Aniso", "Aniso", "Anisotropic Texture Filtering Level.", 40, OnDrawAnisoLevel, OnCompareAnisoLevel, OnExportAnisoLevel));
            Columns.Add(new Column("Alpha", "Alpha", "Indicates whether the texture contains an alpha channel.", 40, OnDrawHasAlpha, OnCompareHasAlpha, OnExportHasAlpha));
            Columns.Add(new Column("RW", "R/W", "Read/Write enables access to the texture data from scripts (GetPixels, SetPixels, etc).\n\nNote however that a copy of the texture data will be made, doubling the amount of memory required for the texture. This is only valid for uncompressed and DTX compressed textures, other types of compressed textures cannot be read from.", 35, OnDrawReadWriteEnabled, OnCompareReadWriteEnabled, OnExportReadWriteEnabled));
            Columns.Add(new Column("PoT", "PoT", "Power of Two\n\nIndicates whether the texture size is Power of Two.", 35, OnDrawIsPowerOfTwo, OnCompareIsPowerOfTwo, OnExportIsPowerOfTwo));
            Columns.Add(new Column("Format", "Format", "Internal representation used for the texture.", 120, OnDrawFormat, OnCompareFormat, OnExportFormat));
            Columns.Add(new Column("FormatShort", "Format Short", "Internal representation used for the texture.", 85, OnDrawFormatShort, OnCompareFormatShort, OnExportFormatShort) { Visible = false });
            Columns.Add(new Column("CompressionQuality", "Compression Quality", "iOS/Android: Quality of texture compression used during import in the editor.", 85, OnDrawCompressionQuality, OnCompareCompressionQuality, OnExportCompressionQuality) { Visible = false });
            Columns.Add(new Column("Mips", "Mips", "Number of mip-maps in texture.", 40, OnDrawMips, OnCompareMips, OnExportMips));
            Columns.Add(new Column("sRGB", "Bypass sRGB Sampling", "Bypass sRGB Sampling\n\nIndicates whether the texture will be converted from gamma to linear space when sampled.", 85, OnDrawIsLinearSampling, OnCompareIsLinearSampling, OnExportIsLinearSampling));
            Columns.Add(new Column("ResizeRatio", "Resize Ratio", "The ratio between the number of pixels in the original texture and the imported texture.", 80, OnDrawPixelRatioPercentage, OnComparePixelRatioPercentage, OnExportPixelRatioPercentage) { Visible = false });
            Columns.Add(new Column("FileExtension", "Extension", "File extension of source texture.", 70, OnDrawFileExtension, OnCompareFileExtension, OnExportFileExtension) { Visible = false });

            Columns.Add(new Column("SpriteImportMode", "Sprite Mode", "Indicates how the the sprite graphic will be extracted from the image.", 90, OnDrawSpriteImportMode, OnCompareSpriteImportMode, OnExportSpriteImportMode));
            Columns.Add(new Column("SpritePackingTag", "Sprite Packing Tag", "The name of an optional sprite atlas into which this texture should be packed.", 90, OnDrawSpritePackingTag, OnCompareSpritePackingTag, OnExportSpritePackingTag));
            Columns.Add(new Column("SpritePixelPerUnit", "Sprite Pixels per Unit", "The number of pixels of width/height in the sprite image that will correspond to one distance unit in world space.", 80, OnDrawSpritePixelPerUnit, OnCompareSpritePixelPerUnit, OnExportSpritePixelPerUnit));

            // Hook into the asset pipeline, since we need to update the list in case the user deletes,
            // moves or imports assets while AudioClip Explorer is running.
            AssetFileWatcher.Imported += AssetFileWatcher_Imported;
            AssetFileWatcher.Deleted += AssetFileWatcher_Deleted;
            AssetFileWatcher.Moved += AssetFileWatcher_Moved;
        }
        #endregion

        #region Dispose
        public void Dispose()
        {
            if (_disposed)
                return;

            // check if it's empty to avoid overwriting a cache file
            // in case the plugin crashed and wasnt able to fill the cache.
            if (!_cache.IsEmpty)
                _cache.Write();

            AssetFileWatcher.Imported -= AssetFileWatcher_Imported;
            AssetFileWatcher.Deleted -= AssetFileWatcher_Deleted;
            AssetFileWatcher.Moved -= AssetFileWatcher_Moved;

            _cache = null;
            _items = null;
            _allitems = null;
            _disposed = true;
            GC.SuppressFinalize(this);
        }
        #endregion

        #region RecalcMemoryUsage
        /// <summary>
        /// Recalculate texture memory consumtion for each entry.
        /// This is neccessary when 'GpuExpandRgb24ToRgba32' option changed.
        /// </summary>
        public void RecalcMemoryUsage()
        {
            foreach (var model in _allitems)
                model.RecalcMemoryUsage();

            DoChanged();
        }
        #endregion

        /// <summary>
        /// Reads the cache file to speed up the SetItems() operation.
        /// </summary>
        public void ReadCacheFile()
        {
            _cache.Read();
        }

        #region DoChanged
        /// <summary>
        /// Raises the Changed event.
        /// Call this method to notify subscribers about list content or state changes.
        /// </summary>
        void DoChanged()
        {
            if (null != Changed)
            {
                var cb = Changed;
                cb.Invoke(this);
            }

            Editor.Repaint();
        }
        #endregion

        #region DoTextureChanged
        /// <summary>
        /// Raises the Changed event.
        /// Call this method to notify subscribers about list content or state changes.
        /// </summary>
        void DoTextureChanged()
        {
            if (null != TextureChanged)
            {
                var cb = TextureChanged;
                cb.Invoke(this);
            }

            Editor.Repaint();
        }
        #endregion

        #region Search/Filter the list
        /// <summary>
        /// Begins changing filter settings.
        /// </summary>
        /// <remarks>
        /// Changing the filter is an expensive operation, because it causes the list to (re)sort.
        /// In order to avoid multiple sorts whenever one filter setting changes, we use do
        ///    BeginChangeFilter()
        ///    ... Change many filter settings here
        ///    EndChangeFilter()
        /// The EndChangeFilter() call will actually cause the list to (re)sort.
        /// </remarks>
        public void BeginChangeFilter()
        {
            _filterUpdateCount++;
        }

        /// <summary>
        /// Ends changing filter settings.
        /// </summary>
        public void EndChangeFilter()
        {
            _filterUpdateCount--;
            UpdateFilter();
        }

        /// <summary>
        /// Filters the list using the specified text and mode.
        /// </summary>
        /// <param name="text">The text a item must contain to match.</param>
        /// <param name="mode">The mode, in which property of the model, the search should check.</param>
        public void SetTextFilter(string text, TextFilterMode mode)
        {
            var parserresult = SearchTextParser.Parse(text);
            SetTextFilter(parserresult, mode);
        }

        void SetTextFilter(SearchTextParser.Result parserresult, TextFilterMode mode)
        {
            _filterResult = parserresult;
            _filterMode = mode;

            UpdateFilter();
        }

        /// <summary>
        /// Adds a texture type to the search filter.
        /// </summary>
        /// <param name="name">The texture type. Any value of TextureUtil2.TextureTypeStrings.</param>
        public void AddTypeFilter(string name)
        {
            if (!HasTypeFilter(name))
            {
                _typeFilter.Add(name);

                UpdateFilter();
            }
        }

        /// <summary>
        /// Removes a texture type from the search filter.
        /// </summary>
        /// <param name="name">The texture type. Any value of TextureUtil2.TextureTypeStrings.</param>
        public void RemoveTypeFilter(string name)
        {
            if (_typeFilter.Remove(name))
                UpdateFilter();
        }

        /// <summary>
        /// Removes all texture types from the search filter.
        /// </summary>
        public void ClearTypeFilter()
        {
            _typeFilter.Clear();
            UpdateFilter();
        }

        /// <summary>
        /// Gets whether the search filter contains the specified texture type.
        /// </summary>
        /// <param name="name">The texture type. Any value of TextureUtil2.TextureTypeStrings.</param>
        /// <returns>true when it contains the specified texture type, false otherwise.</returns>
        public bool HasTypeFilter(string name)
        {
            if (_typeFilter.Contains(name, StringComparer.OrdinalIgnoreCase))
                return true;

            return false;
        }

        /// <summary>
        /// Gets how many texture type filters are set.
        /// </summary>
        public int GetTypeFilterCount()
        {
            return _typeFilter.Count;
        }

        /// <summary>
        /// Updates the content of the list using the current search filter.
        /// </summary>
        void UpdateFilter()
        {
            if (_filterUpdateCount > 0)
                return; // changing filter not ended yet

            // build the lookup table to speed up the operation to check
            // if a certain texture is whether visible due to the texture type filter.
            _typeFilterDict = new Dictionary<string, string>();
            foreach (var t in _typeFilter)
            {
                if (!_typeFilterDict.ContainsKey(t))
                    _typeFilterDict.Add(t, t);
            }

            // check each item if it's included in the search filter
            _items = new List<Model>(_allitems.Count);
            for (var n = 0; n < _allitems.Count; ++n)
            {
                var item = _allitems[n];
                if (IsIncludedInFilter(item))
                    _items.Add(item);
            }

            // notify about changed
            DoChanged();
        }

        /// <summary>
        /// Gets whether the specified model matchs the filter criteria.
        /// </summary>
        /// <returns>true when the filter is matching and the item has to be included in the list, false otherwise.</returns>
        bool IsIncludedInFilter(Model model)
        {
            // check if the texture type (normalmap, reflection, etc) is allowed to
            // be displayed due to any existing type-filter that might be set.
            if (_typeFilterDict.Keys.Count > 0)
            {
                if (!_typeFilterDict.Keys.Contains(model.TextureTypeString, StringComparer.OrdinalIgnoreCase))
                    return false;
            }

            // filter does not contain any filter-text, so the item should be displayed
            if (_filterResult.NamesExpr.Count == 0)
                return true;

            // check if the filter text occurs in the name
            string modelname = null;
            switch (_filterMode)
            {
                case TextFilterMode.Name:
                    modelname = model.AssetName;
                    break;
                case TextFilterMode.Path:
                    modelname = model.AssetPath;
                    break;
            }

            return _filterResult.IsNameMatch(modelname);
        }
        #endregion

        #region SetItems
        /// <summary>
        /// Sets the textures that should be shown in Texture Overview.
        /// </summary>
        /// <param name="paths">The asset paths of assets to add to the list.</param>
        public void SetItems(List<string> paths)
        {
            UnityEngine.Profiler.BeginSample("Listbox.SetItems");

            // get memory usage of all assets currently loaded in unity
            // we use this to calculate a sane number of memory we can use while
            // loading textures. without limiting this, unity would crash with an out-of-memory error.
            long availableMemory = 0;
            {
                // release memory of unused assets to have more memory for texture overview when filling the cache file.
                // having more memory to work with means faster loading.
                EditorUtility2.UnloadUnusedAssetsImmediate();

                // get size of all assets currently loaded
                //var activeAssets = UnityEngine.Object.FindObjectsOfTypeIncludingAssets(typeof(UnityEngine.Object));
                var activeAssets = Resources.FindObjectsOfTypeAll<UnityEngine.Object>();
                long usedMemory = 0;
                foreach (var o in activeAssets)
                    usedMemory += Profiler.GetRuntimeMemorySize(o);

                // calc how much memory we have to work with until we need to free resources
                // we want to leave 256mb free and never use more than 512mb
                var _256mb = 256 * 1024 * 1024;
                var _512mb = 512 * 1024 * 1024;
                var memoryLimit32bit = Int32.MaxValue - _256mb;
                availableMemory = Math.Max(0, Math.Min(_512mb, memoryLimit32bit - usedMemory));

                // warn if memory is low
                if (availableMemory < _256mb)
                    Debug.LogWarning(string.Format("{0}: Unity is currently using a lot of memory ({1} MB). This might cause (performance) problems when opening Texture Overview for the first time. In such case, please open an empty Scene, make sure no object is currently selected and re-open Texture Overview. After this step, Texture Overview has built its cache and memory usage won't affect Texture Overview anymore.", Globals.ProductTitle, usedMemory / 1024 / 1024));
            }

            // build a list of texture files only
            _allitems = new List<Model>();
            var texpaths = new List<string>(paths.Count);
            foreach (var path in paths)
            {
                if (!IsSupportedFile(path))
                    continue;
                texpaths.Add(path);
            }

            try
            {
                _cache.BeginGetEntry();

                using (var progressbar = new EditorGUI2.ModalProgressBar(string.Format("{0}: Loading", Globals.ProductTitle), true))
                {
                    // indicates how many bytes are loaded during initialization
                    // and is used to release memory at some threshold to prevent the
                    // editor to crash with an out-of-mem exception.
                    long loadedsize = 0;

                    // create the model-representation for each texture in texpaths
                    for (var n = 0; n < texpaths.Count; ++n)
                    {
                        var path = texpaths[n];

                        // report the progress to the user, since it can be a time consuming operation to read many textures.
                        if (progressbar.TotalElapsedTime > 1.0f && progressbar.ElapsedTime > 0.1f)
                        {
                            var progress = n / (float)texpaths.Count;
                            var text = string.Format("[{1} remaining] {0}", FileUtil2.GetFileName(path), texpaths.Count - n - 1);
                            if (progressbar.Update(text, progress))
                                break;
                        }

                        // initialize the model-representation
                        Model model = null;
                        loadedsize += InitModel(ref model, path);

                        // check if we have loaded so much memory, that we need to release it to avoid an editor crash
                        CheckUnloadUnused(ref loadedsize, availableMemory);

                        _allitems.Add(model);
                    }

                    // if it actually loaded new texture settings make
                    // sure to save the cache file
                    if (loadedsize > 0)
                        _cache.Write();
                }
            }
            finally
            {
                _cache.EndGetEntry();
            }

            _items = new List<Model>(_allitems);
            Sort();
            DoChanged();

            EditorUtility2.UnloadUnusedAssetsImmediate();

            UnityEngine.Profiler.EndSample();
        }
        #endregion

        #region IsSupportedFile
        /// <summary>
        /// Gets whether the asset of the specified path is supported to be displayed in Texture Overview.
        /// </summary>
        /// <param name="path">The relative asset path</param>
        bool IsSupportedFile(string path)
        {
            var type = AssetDatabase2.GetAssetType(path);
            if (type == null)
                return false;

            if (type == typeof(Texture) || type.IsSubclassOf(typeof(Texture)))
                return true;

            //if (type == typeof(Texture))
            //    return true;

            //if (type == typeof(Texture2D))
            //    return true;

            //if (type == typeof(Cubemap))
            //    return true;

            return false;
        }
        #endregion

        #region CheckUnloadUnused
        /// <summary>
        /// Call this method after every InitModel(). It sums the sizes of the loaded
        /// clips and makes sure to unload those when a certail memory consumtion threshold has been reached.
        /// </summary>
        void CheckUnloadUnused(ref long loadedsize, long availableMemory)
        {
            if (loadedsize <= 0)
                return;

            // if a certain memory threshold has been reached
            // we force the editor to unload unused assets.
            // without doing this, the editor will crash by an out-of-memory exception eventually.
            if (loadedsize >= availableMemory)
            {
                _cache.Write(); // also a good idea to write the cache file, in case unity crashes for an unknown reason, we have at least the textures already read into the cache
                EditorUtility2.UnloadUnusedAssetsImmediate();
                loadedsize = 0;
                System.Threading.Thread.Sleep(1); // ios editor workaround: the ios editor does not immediately release unused memory, but after a sleep. meh.
            }
        }
        #endregion

        #region InitModel
        /// <summary>
        /// Initializes the specified model of the specified path.
        /// </summary>
        /// <returns>
        /// returns the amount of memory the editor had to allocate to initialize the model.
        /// </returns>
        int InitModel(ref Model model, string path)
        {
            // do we alreadd have a model for the specified path?
            if (null == model)
            {
                // nope, try to get it from the cache
                var guid = AssetDatabase.AssetPathToGUID(path);
                if (_cache.TryGetEntry(guid, PlatformGroup, out model, true))
                    return 0; // read from cache

                // it's not in the cache yet, so create a new Model instead
                model = new Model();
            }

            // it's not located in cache, initialize it the expensive way
            model.Init(path, Platform);

            // and now add it to the cache
            _cache.UpdateEntry(model, PlatformGroup);

            // return the cost of the texture inside the editor to free memory at some point
            return GetEditorMemoryCost(model);
        }
        #endregion

        int GetEditorMemoryCost(Model model)
        {
            // calculate how much memory the texture costs inside the editor.
            // if the texture is NOT readable, it is twice the cost, otherweise it's the same cost.
            // i guess unity always keeps a copy of the texture in cpu memory when running in the editor
            var editorsize = model.RuntimeSize * (model.IsReadable ? 1 : 2);

            #region OSXEditor, iOS Hack
            // the following is probably an unity bug:
            // on OSX with build target iOS selected, a texture costs additional 5 times more.
            // OSX editor, iOS: PVRTC_RGBA4 512x512 should be 300kb, but is actually 1.5mb (inside the editor)!
            // figured that out using the Profiler.GetRuntimeMemorySize() method.
            // NOTE: after having filed a bug-report, Unity says this is intented behaviour for the editor (because it does not directly support the PVRTC format, but uses another one internally).
#if UNITY_4
            var isIOS = PlatformGroup == BuildTargetGroup.iPhone;
#else
            var isIOS = PlatformGroup == BuildTargetGroup.iOS;
#endif
            if (Application.platform == RuntimePlatform.OSXEditor && isIOS)
                editorsize *= 5;
            #endregion

            // the cost of the texture importer varies depending on the platform.
            // OSX=400 bytes, windows=644 bytes. lets be generous and say it's 1kb
            editorsize += 1024;

            return editorsize;
        }

        #region FindModel
        /// <summary>
        /// Finds the model with the specified assetPath.
        /// </summary>
        /// <param name="assetPath">The path.</param>
        /// <returns>The model on success, null otherwise.</returns>
        Model FindModel(string assetPath)
        {
            // we could also use a dictionary to speedup the search,
            // but this has not been a performance issue yet, not even with 20000 textures.
            foreach (var item in _allitems)
            {
                if (string.Equals(assetPath, item.AssetPath, StringComparison.OrdinalIgnoreCase))
                    return item;
            }
            return null;
        }
        #endregion

        #region Helper methods to get selected paths/models/textures
        /// <summary>
        /// Gets all models that are currently selected in Texture Overview.
        /// </summary>
        List<Model> GetSelectedModels()
        {
            var selection = SelectedItems;
            var objects = new List<Model>(selection.Length);
            foreach (var item in selection)
            {
                var model = item as Model;
                objects.Add(model);
            }
            return objects;
        }

        /// <summary>
        /// Gets all paths that are currently selected in Texture Overview.
        /// </summary>
        List<string> GetSelectedPaths()
        {
            var selection = SelectedItems;
            var paths = new List<string>(selection.Length);
            foreach (var item in selection)
            {
                var model = item as Model;
                if (!string.IsNullOrEmpty(model.AssetPath))
                    paths.Add(model.AssetPath);
            }
            return paths;
        }

        /// <summary>
        /// Gets all textures that are currently selected in Texture Overview.
        /// </summary>
        /// <remarks>
        /// To return the Texture, the asset actually needs to be loaded into memory.
        /// This can be an expensive operation and since Unity is 32bit only, it might even
        /// crash the editor when you try to get/load more textures into memory than there
        /// is available due to the 32bit limit.
        /// Unlike the Unity editor, we display a progressbar during this time, so it won't look like
        /// the editor freezed when a large amount of textures are selected.
        /// </remarks>
        /// <param name="showprogress">Indicates whether a progressbar should be shown.</param>
        /// <param name="maxcount">Maximum count of textures that are allowed  to be returned.</param>
        List<UnityEngine.Object> GetSelectedAssets(bool showprogress, int maxcount)
        {
            var objects = new List<UnityEngine.Object>(64);
            using (var progressbar = new EditorGUI2.ModalProgressBar(string.Format("{0}: Loading", Globals.ProductTitle), true))
            {
                var selection = SelectedItems;
                for (var n = 0; n < Mathf.Min(maxcount, selection.Length); ++n)
                {
                    var model = selection[n] as Model;
                    if (model.HasError)
                        continue;

                    if (showprogress && progressbar.TotalElapsedTime > 1.0f && progressbar.ElapsedTime > 0.1f)
                    {
                        var progress = n / (float)selection.Length;
                        var text = string.Format("[{1} remaining] {0}", model.AssetName, selection.Length - n - 1);
                        if (progressbar.Update(text, progress))
                            break;
                    }

                    var asset = AssetDatabase.LoadMainAssetAtPath(model.AssetPath);
                    if (null != asset)
                        objects.Add(asset);
                }
            }
            return objects;
        }
        #endregion

        #region OnBeginDrag
        /// <summary>
        /// Occurs at the beginning of a Drag&Drop operation.
        /// </summary>
        protected override void OnBeginDrag(int index, out UnityEngine.Object[] objects, out string[] paths)
        {
            paths = GetSelectedPaths().ToArray();
            objects = GetSelectedAssets(SelectedItemsCount > 20, int.MaxValue).ToArray();
        }
        #endregion

        #region OnSorting
        /// <summary>
        /// Occurs when the user requests to sort the list.
        /// </summary>
        /// <returns>Returns the array of items to sort.</returns>
        protected override object[] OnBeforeSortItems()
        {
            return _allitems.ToArray();
        }

        /// <summary>
        /// Occurs after sorting completed.
        /// </summary>
        /// <param name="models">The sorted data. This is the data returned by OnBeforeSortItems(), but sorted.</param>
        protected override void OnAfterSortItems(object[] models)
        {
            base.OnAfterSortItems(models);

            _allitems = new List<Model>((Model[])models); // write the sorted data back to our data model
            SetTextFilter(_filterResult, _filterMode); // make sure any existing filter will still have impact on the now sorted list
        }
        #endregion

        #region OnSelectionChange
        /// <summary>
        /// Occurs when the list selection changed.
        /// </summary>
        protected override void OnSelectionChange()
        {
            base.OnSelectionChange();
            DoChanged();
        }
        #endregion

        #region OnItemContextMenu
        /// <summary>
        /// Occurs when the user requests the context menu.
        /// </summary>
        protected override void OnItemContextMenu(GUIListViewContextMenuArgs args)
        {
            base.OnItemContextMenu(args);

            if (SelectedItemsCount < 1)
                return; // no item selected, do not open a context menu

            GUIUtility.hotControl = 0;
            var model = args.Model as Model;

            var menu = new GenericMenu();
            menu.AddItem(new GUIContent(Application.platform == RuntimePlatform.OSXEditor ? "Reveal in Finder" : "Show in Explorer"), false, SelectedItemsCount <= 10 ? OnContextMenuShowInExplorer : (GenericMenu.MenuFunction2)null, model);
            menu.AddItem(new GUIContent("Open %enter"), false, OnContextMenuOpenWithDefaultApp, model);
            menu.AddItem(new GUIContent("Delete... _delete"), false, OnContextMenuDelete);
            menu.AddItem(new GUIContent(string.Empty), false, null);
            menu.AddItem(new GUIContent("Select in Project _enter"), false, OnContextMenuSelect);
            menu.AddItem(new GUIContent("Find References In Scene"), false, SelectedItemsCount == 1 ? OnContextMenuFindReferencesInScene : (GenericMenu.MenuFunction)null);
            menu.AddItem(new GUIContent("Find Materials in Project"), false, OnContextMenuFindMaterialsInProject);
            menu.AddItem(new GUIContent("Find Prefabs in Project"), false, OnContextMenuFindPrefabsInProject);
            menu.AddItem(new GUIContent("Find Prefabs and Scenes in Project"), false, OnContextMenuFindPrefabsAndScenesInProject);
            menu.AddItem(new GUIContent(string.Empty), false, null);
            menu.AddItem(new GUIContent("Reimport"), false, OnContextMenuReimport);
            menu.AddItem(new GUIContent(string.Empty), false, null);
            menu.AddItem(new GUIContent("Copy Full Path"), false, OnContextMenuCopyFullPath);

            // display the context menu. make sure to use the provided args.MenuLocation position
            // rather than 'Event.current.mousePosition', because the user could have been pressed
            // the context-menu key as well, thus mousePosition would be most likely wrong.
            menu.DropDown(new Rect(args.MenuLocation.x, args.MenuLocation.y, 0, 0));
            Event.current.Use();
            Editor.Repaint();
        }

        void OnContextMenuShowInExplorer(object userData)
        {
            var objects = GetSelectedAssets(SelectedItemsCount > 20, int.MaxValue);
            EditorApplication2.ShowInExplorer(objects.ToArray());
            Editor.Repaint();
        }

        void OnContextMenuOpenWithDefaultApp(object userData)
        {
            var paths = GetSelectedPaths();
            EditorApplication2.OpenAssets(paths.ToArray());
            Editor.Repaint();
        }

        void OnContextMenuDelete()
        {
            var paths = GetSelectedPaths();
            AssetDatabase2.Delete(paths);
            Editor.Focus(); // make sure to focus our plugin window again after the user confirmed the messagebox
            Editor.Repaint();
        }

        void OnContextMenuSelect()
        {
            var clips = GetSelectedAssets(SelectedItemsCount > 20, int.MaxValue);
            Selection.objects = clips.ToArray();
        }

        void OnContextMenuFindMaterialsInProject()
        {
            FindAssetUsageWindow.FindUsageInProject(Globals.ProductId, Globals.ProductTitle, GetSelectedPaths(), new[] { typeof(Material) });
        }

        void OnContextMenuFindPrefabsInProject()
        {
            FindAssetUsageWindow.FindUsageInProject(Globals.ProductId, Globals.ProductTitle, GetSelectedPaths(), new[] { typeof(GameObject) });
        }

        void OnContextMenuFindPrefabsAndScenesInProject()
        {
            FindAssetUsageWindow.FindUsageInProject(Globals.ProductId, Globals.ProductTitle, GetSelectedPaths(), new[] { typeof(GameObject), typeof(AssetDatabase2.UnityScene) });
        }

        void OnContextMenuFindReferencesInScene()
        {
            var objects = GetSelectedAssets(false, 1);
            if (objects.Count > 0)
            {
                EditorApplication2.FindReferencesInScene(objects[0]);
                EditorUtility2.UnloadUnusedAssetsImmediate();
            }
        }

        void OnContextMenuReimport()
        {
            var paths = GetSelectedPaths();
            AssetDatabase2.Reimport(paths, 10);
        }

        void OnContextMenuCopyFullPath()
        {
            var paths = GetSelectedPaths();
            ClipboardUtil.CopyPaths(paths);
        }
        #endregion

        #region OnItemKeyDown
        /// <summary>
        /// Occurs when the user presses a key.
        /// </summary>
        protected override void OnItemKeyDown(ref GUIListViewItemKeyDownArgs args)
        {
            switch (Event.current.keyCode)
            {
                case KeyCode.Delete:
                    OnContextMenuDelete();
                    args.Handled = true;
                    break;

                case KeyCode.Return:
                    if (Event.current.control) // Ctrl+Return opens selected textures in the default application
                    {
                        OnContextMenuOpenWithDefaultApp(args.Model);
                        args.Handled = true;
                    }
                    else // Return assigns selected textures to the Unity Inspector
                    {
                        OnContextMenuSelect();
                        args.Handled = true;
                    }
                    break;
            }
        }
        #endregion

        #region OnItemDoubleClick
        /// <summary>
        /// Occurs when the user double clicks an item.
        /// </summary>
        /// <param name="index">The index of the item.</param>
        protected override void OnItemDoubleClick(int index)
        {
            base.OnItemDoubleClick(index);

            // a double-click actually forces the list to have only 1 item selected,
            // so we also just get one clip here.
            var objs = GetSelectedAssets(false, 1);
            if (objs.Count > 0)
            {
                ChangeUnitySelectionTime = DateTime.Now.TimeOfDay.TotalSeconds; // store at which time the user involked the selected model, in order to avoid a feedback loop if the plugin is listening to selection changes.
                Selection.activeObject = objs[0];
                EditorGUIUtility.PingObject(objs[0]);
            }
        }
        #endregion

        #region OnGetItemKeyword
        /// <summary>
        /// Gets the item keyword for the specified args.
        /// </summary>
        /// <remarks>
        /// The item-keyword is used to jump to a particular item in the list
        /// when the user pressed a key. When a model begins with the keyword(sequence) the list jumps to it.
        /// </remarks>
        protected override string OnGetItemKeyword(GUIListViewGetItemKeywordArgs args)
        {
            var model = args.Model as Model;
            if (model != null)
                return model.AssetName;

            return null;
        }
        #endregion

        #region OnGetItem
        /// <summary>
        /// Gets the item at the specified index.
        /// </summary>
        protected override object OnGetItem(int index)
        {
            if (index < 0 || index >= _items.Count)
                return null;

            return _items[index];
        }
        #endregion

        #region OnGetItemCount
        /// <summary>
        /// Gets the count of items in the list.
        /// </summary>
        protected override int OnGetItemCount()
        {
            return _items.Count;
        }
        #endregion

        #region OnGetItemText
        /// <summary>
        /// Gets the item text of the specified column.
        /// </summary>
        protected override string OnGetItemText(GUIListViewGetItemTextArgs args)
        {
            var column = args.Column as Column;
            return column.Exporter(args.Model as Model);
        }
        #endregion

        #region OnDrawItem
        /// <summary>
        /// Occurs when a list item is requested to draw.
        /// </summary>
        /// <param name="args">The data containing all the information needed to draw the item.</param>
        protected override void OnDrawItem(GUIListViewDrawItemArgs args)
        {
            var model = args.Model as Model;
            if (null == model)
                return;

            // if the texture could not be read, thus has an error, just display
            // a red box with the path.
            if (model.HasError)
            {
                if (args.Column == this.FirstVisibleColumn)
                {
                    DrawItemImageHelper(ref args.ItemRect, GUIContent2.Temp(Images.Error16x16, "The texture could not be loaded."), new Vector2(16, 16));
                    args.ItemRect.y += 4; args.ItemRect.height -= 4;
                    EditorGUI2.Label(args.ItemRect, "ERROR: " + model.AssetPath, args.Selected);
                }
                return;
            }

            // if this is the first column in the list, display an icon there
            if (args.Column.IsPrimaryColumn)
                DrawItemImageHelper(ref args.ItemRect, model.GetSmallImage(), new Vector2(16, 16));

            // make the text appear vertically centered in the row
            args.ItemRect.width -= 5;
            args.ItemRect.y += 4; args.ItemRect.height -= 4;

            // draw the models value using the specified custom drawer method
            var column = args.Column as Column;
            if (null != column && null != column.Drawer)
                column.Drawer(model, args);
        }
        #endregion

        #region OnItemHide
        /// <summary>
        /// Called when the item goes out of view.
        /// </summary>
        /// <param name="model">The Model</param>
        protected override void OnItemHide(object item)
        {
            base.OnItemHide(item);

            var model = item as Model;
            if (null == model)
                return;

            model.ClearSmallImage();
        }
        #endregion

        #region Draw/Compare AssetPath
        void OnDrawAssetPath(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.PathLabel(args.ItemRect, model.AssetPath, args.Selected);
        }

        int OnCompareAssetPath(Model x, Model y)
        {
            return string.Compare(x.AssetPath, y.AssetPath, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportAssetPath(Model model)
        {
            return model.AssetPath;
        }
        #endregion

        #region Draw/Compare AssetName
        void OnDrawAssetName(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.AssetName, args.Selected);
        }

        int OnCompareAssetName(Model x, Model y)
        {
            return string.Compare(x.AssetName, y.AssetName, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportAssetName(Model model)
        {
            return model.AssetName;
        }
        #endregion

        #region Draw/Compare TextureType
        void OnDrawImportType(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.TextureTypeString, args.Selected);
        }

        int OnCompareImportType(Model x, Model y)
        {
            return string.Compare(x.TextureTypeString, y.TextureTypeString, StringComparison.CurrentCultureIgnoreCase);
        }

        string OnExportImportType(Model model)
        {
            return model.TextureTypeString;
        }
        #endregion

        #region Draw/Compare MaxTextureSize
        void OnDrawMaxSize(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.MaxTextureSizeString, args.Selected);
        }

        int OnCompareMaxSize(Model x, Model y)
        {
            return x.MaxTextureSize.CompareTo(y.MaxTextureSize);
        }

        string OnExportMaxSize(Model model)
        {
            return model.MaxTextureSize.ToString();
        }
        #endregion

        #region Draw/Compare TextureFormat
        void OnDrawFormat(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.TextureFormatString, args.Selected);
        }

        int OnCompareFormat(Model x, Model y)
        {
            return string.Compare(x.TextureFormatString, y.TextureFormatString, StringComparison.CurrentCultureIgnoreCase);
        }

        string OnExportFormat(Model model)
        {
            return model.TextureFormatString;
        }
        #endregion

        #region Draw/Compare TextureFormatShort
        void OnDrawFormatShort(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.TextureFormatShortString, args.Selected);
        }

        int OnCompareFormatShort(Model x, Model y)
        {
            return string.Compare(x.TextureFormatShortString, y.TextureFormatShortString, StringComparison.CurrentCultureIgnoreCase);
        }

        string OnExportFormatShort(Model model)
        {
            return model.TextureFormatShortString;
        }
        #endregion

        #region Draw/Compare CompressionQuality
        void OnDrawCompressionQuality(Model model, GUIListViewDrawItemArgs args)
        {
            //args.ItemRect.y -= 2;
            //EditorGUI.ProgressBar(args.ItemRect, model.CompressionQuality / 100.0f, model.CompressionQualityString);
            EditorGUI2.Label(args.ItemRect, model.CompressionQualityString, args.Selected);
        }

        int OnCompareCompressionQuality(Model x, Model y)
        {
            return x.CompressionQualityString.CompareTo(y.CompressionQualityString);
        }

        string OnExportCompressionQuality(Model model)
        {
            return model.CompressionQualityString;
        }
        #endregion

        #region Draw/Compare FilterMode
        void OnDrawFilterMode(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.FilterModeString, args.Selected);
        }

        int OnCompareFilterMode(Model x, Model y)
        {
            return string.Compare(x.FilterModeString, y.FilterModeString, StringComparison.CurrentCultureIgnoreCase);
        }

        string OnExportFilterMode(Model model)
        {
            return model.FilterModeString;
        }
        #endregion

        #region Draw/Compare WrapMode
        void OnDrawWrapMode(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.WrapModeString, args.Selected);
        }

        int OnCompareWrapMode(Model x, Model y)
        {
            return string.Compare(x.WrapModeString, y.WrapModeString, StringComparison.CurrentCultureIgnoreCase);
        }

        string OnExportWrapMode(Model model)
        {
            return model.WrapModeString;
        }
        #endregion

        #region Draw/Compare MipmapCount
        void OnDrawMips(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.MipmapCountString, args.Selected);
        }

        int OnCompareMips(Model x, Model y)
        {
            return x.MipmapCount.CompareTo(y.MipmapCount);
        }

        string OnExportMips(Model model)
        {
            return model.MipmapCount.ToString();
        }
        #endregion

        #region Draw/Compare IsLinearSampling
        void OnDrawIsLinearSampling(Model model, GUIListViewDrawItemArgs args)
        {
            var oldenable = GUI.enabled;
            GUI.enabled = false;
            EditorGUI.Toggle(args.ItemRect, model.IsLinearSampling);
            GUI.enabled = oldenable;
        }

        int OnCompareIsLinearSampling(Model x, Model y)
        {
            return x.IsLinearSampling.CompareTo(y.IsLinearSampling);
        }

        string OnExportIsLinearSampling(Model model)
        {
            return model.IsLinearSampling.ToString();
        }
        #endregion

        #region Draw/Compare FileExtension
        void OnDrawFileExtension(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.FileExtension, args.Selected);
        }

        int OnCompareFileExtension(Model x, Model y)
        {
            return string.Compare(x.FileExtension, y.FileExtension, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportFileExtension(Model model)
        {
            return model.FileExtension;
        }
        #endregion

        #region Draw/Compare StorageSize
        void OnDrawStorageSize(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.StorageSizeString, args.Selected);
        }

        int OnCompareStorageSize(Model x, Model y)
        {
            return x.StorageSize.CompareTo(y.StorageSize);
        }

        string OnExportStorageSize(Model model)
        {
            return model.StorageSize.ToString();
        }
        #endregion

        #region Draw/Compare RuntimeSize
        void OnDrawRuntimeSize(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.RuntimeSizeString, args.Selected);
        }

        int OnCompareRuntimeSize(Model x, Model y)
        {
            return x.RuntimeSize.CompareTo(y.RuntimeSize);
        }

        string OnExportRuntimeSize(Model model)
        {
            return model.RuntimeSize.ToString();
        }
        #endregion

        #region Draw/Compare CpuSize
        void OnDrawCpuSize(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.CpuSizeString, args.Selected);
        }

        int OnCompareCpuSize(Model x, Model y)
        {
            return x.CpuSize.CompareTo(y.CpuSize);
        }

        string OnExportCpuSize(Model model)
        {
            return model.CpuSize.ToString();
        }
        #endregion

        #region Draw/Compare GpuSize
        void OnDrawGpuSize(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.GpuSizeString, args.Selected);
        }

        int OnCompareGpuSize(Model x, Model y)
        {
            return x.GpuSize.CompareTo(y.GpuSize);
        }

        string OnExportGpuSize(Model model)
        {
            return model.GpuSize.ToString();
        }
        #endregion

        #region Draw/Compare PixelRatioPercentage
        void OnDrawPixelRatioPercentage(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, GUIContent2.Temp(model.PixelRatioPercentageString, model.PixelRatioTooltip), args.Selected);
        }

        int OnComparePixelRatioPercentage(Model x, Model y)
        {
            return x.PixelRatioPercentage.CompareTo(y.PixelRatioPercentage);
        }

        string OnExportPixelRatioPercentage(Model model)
        {
            return model.PixelRatioPercentageString;
        }
        #endregion

        #region Draw/Compare Width
        void OnDrawWidth(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.WidthString, args.Selected);
        }

        int OnCompareWidth(Model x, Model y)
        {
            return x.Width.CompareTo(y.Width);
        }

        string OnExportWidth(Model model)
        {
            return model.Width.ToString();
        }
        #endregion

        #region Draw/Compare Height
        void OnDrawHeight(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.HeightString, args.Selected);
        }

        int OnCompareHeight(Model x, Model y)
        {
            return x.Height.CompareTo(y.Height);
        }

        string OnExportHeight(Model model)
        {
            return model.Height.ToString();
        }
        #endregion

        #region Draw/Compare OriginalWidth
        void OnDrawOriginalWidth(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.OrgWidthString, args.Selected);
        }

        int OnCompareOriginalWidth(Model x, Model y)
        {
            return x.OrgWidth.CompareTo(y.OrgWidth);
        }

        string OnExportOriginalWidth(Model model)
        {
            return model.OrgWidth.ToString();
        }
        #endregion

        #region Draw/Compare OriginalHeight
        void OnDrawOriginalHeight(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.OrgHeightString, args.Selected);
        }

        int OnCompareOriginalHeight(Model x, Model y)
        {
            return x.OrgHeight.CompareTo(y.OrgHeight);
        }

        string OnExportOriginalHeight(Model model)
        {
            return model.OrgHeight.ToString();
        }
        #endregion

        #region Draw/Compare AnisoLevel
        void OnDrawAnisoLevel(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.AnisoLevelString, args.Selected);
        }

        int OnCompareAnisoLevel(Model x, Model y)
        {
            return x.AnisoLevel.CompareTo(y.AnisoLevel);
        }

        string OnExportAnisoLevel(Model model)
        {
            return model.AnisoLevel.ToString();
        }
        #endregion

        #region Draw/Compare HasAlpha
        void OnDrawHasAlpha(Model model, GUIListViewDrawItemArgs args)
        {
            var oldenable = GUI.enabled;
            GUI.enabled = false;
            EditorGUI.Toggle(args.ItemRect, model.HasAlpha);
            GUI.enabled = oldenable;
        }

        int OnCompareHasAlpha(Model x, Model y)
        {
            var xx = x.HasAlpha ? 1 : 0;
            var yy = y.HasAlpha ? 1 : 0;
            return xx - yy;
        }

        string OnExportHasAlpha(Model model)
        {
            return model.HasAlpha.ToString();
        }
        #endregion

        #region Draw/Compare IsPowerOfTwo
        void OnDrawIsPowerOfTwo(Model model, GUIListViewDrawItemArgs args)
        {
            var oldenable = GUI.enabled;
            GUI.enabled = false;
            EditorGUI.Toggle(args.ItemRect, model.IsPowerOfTwo);
            GUI.enabled = oldenable;
        }

        int OnCompareIsPowerOfTwo(Model x, Model y)
        {
            var xvalue = x.IsPowerOfTwo ? 1 : 0;
            var yvalue = y.IsPowerOfTwo ? 1 : 0;
            return xvalue - yvalue;
        }

        string OnExportIsPowerOfTwo(Model model)
        {
            return model.IsPowerOfTwo.ToString();
        }
        #endregion

        #region Draw/Compare ReadWrite Enabled
        void OnDrawReadWriteEnabled(Model model, GUIListViewDrawItemArgs args)
        {
            var oldenable = GUI.enabled;
            GUI.enabled = false;
            EditorGUI.Toggle(args.ItemRect, model.IsReadable);
            GUI.enabled = oldenable;
        }

        int OnCompareReadWriteEnabled(Model x, Model y)
        {
            var xvalue = x.IsReadable ? 1 : 0;
            var yvalue = y.IsReadable ? 1 : 0;
            return xvalue - yvalue;
        }

        string OnExportReadWriteEnabled(Model model)
        {
            return model.IsReadable.ToString();
        }
        #endregion

        #region Draw/Compare SpriteImportMode
        void OnDrawSpriteImportMode(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.SpriteImportMode != SpriteImportMode.None ? model.SpriteImportModeString : "", args.Selected);
        }

        int OnCompareSpriteImportMode(Model x, Model y)
        {
            return string.Compare(x.SpriteImportModeString, y.SpriteImportModeString, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportSpriteImportMode(Model model)
        {
            return model.SpriteImportModeString;
        }
        #endregion

        #region Draw/Compare SpritePackingTag
        void OnDrawSpritePackingTag(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.SpriteImportMode != SpriteImportMode.None ? model.SpritePackingTag : "", args.Selected);
        }

        int OnCompareSpritePackingTag(Model x, Model y)
        {
            return string.Compare(x.SpritePackingTag, y.SpritePackingTag, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportSpritePackingTag(Model model)
        {
            return model.SpritePackingTag;
        }
        #endregion

        #region Draw/Compare SpritePixelPerUnit
        void OnDrawSpritePixelPerUnit(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.SpriteImportMode != SpriteImportMode.None ? model.SpritePixelPerUnitString : "", args.Selected);
        }

        int OnCompareSpritePixelPerUnit(Model x, Model y)
        {
            return string.Compare(x.SpritePixelPerUnitString, y.SpritePixelPerUnitString, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportSpritePixelPerUnit(Model model)
        {
            return model.SpritePixelPerUnitString;
        }
        #endregion
        
        #region AssetFileWatcher
        /// <summary>
        /// Occurs when an asset has been moved in the project.
        /// </summary>
        void AssetFileWatcher_Moved(string[] oldPaths, string[] newPaths)
        {
            int processed = 0;
            long loadedsize = 0;
            for (var n = 0; n < oldPaths.Length; ++n)
            {
                if (!IsSupportedFile(oldPaths[n]))
                    continue; // not the type of asset we're interested in
                processed++;

                var model = FindModel(oldPaths[n]);
                if (null != model)
                {
                    loadedsize += InitModel(ref model, newPaths[n]);
                    CheckUnloadUnused(ref loadedsize, 128 * 1024 * 1024);
                }
            }

            if (processed > 0)
            {
                Sort();
                DoChanged();
                DoTextureChanged();

                // write updated cache to disk
                if (!_cache.IsEmpty)
                    _cache.Write();
            }
        }

        /// <summary>
        /// Occurs when an asset has been deleted from the project.
        /// </summary>
        void AssetFileWatcher_Deleted(string[] paths)
        {
            int processed = 0;
            foreach (var path in paths)
            {
                if (!IsSupportedFile(path))
                    continue; // not the type of asset we're interested in
                processed++;

                var model = FindModel(path);
                if (null != model)
                {
                    _allitems.Remove(model);
                    _items.Remove(model);
                }
            }

            if (processed > 0)
            {
                DoChanged();
                DoTextureChanged();

                // write updated cache to disk
                if (!_cache.IsEmpty)
                    _cache.Write();
            }
        }

        /// <summary>
        /// Occurs when an asset has been imported into the project.
        /// </summary>
        void AssetFileWatcher_Imported(string[] paths)
        {
            int processed = 0;
            var addeditem = false;
            long loadedsize = 0;
            foreach (var path in paths)
            {
                if (!IsSupportedFile(path))
                    continue; // not the type of asset we're interested in
                processed++;

                // try to find the model
                var model = FindModel(path);
                if (null != model)
                {
                    loadedsize += InitModel(ref model, path);
                    continue;
                }

                // this is a new asset, add it to our list
                loadedsize += InitModel(ref model, path);
                _allitems.Add(model);

                // if the asset is visible to the current filter, add it to the filtered list as well
                if (IsIncludedInFilter(model))
                    _items.Add(model);

                addeditem = true;
                CheckUnloadUnused(ref loadedsize, 128 * 1024 * 1024);
            }

            if (processed > 0)
            {
                if (addeditem)
                    Sort();

                DoChanged();
                DoTextureChanged();

                // write updated cache to disk
                if (!_cache.IsEmpty)
                    _cache.Write();
            }
        }
        #endregion

        #region GetMemoryUsage
        /// <summary>
        /// Gets memory usages of all textures currently added to the listbox.
        /// </summary>
        /// <param name="runtimeUsage">The output runtime usage</param>
        /// <param name="storageUsage">The output storage usage</param>
        public void GetMemoryUsage(out TextureMemoryUsageInfo cpuUsage, out TextureMemoryUsageInfo gpuUsage,
            out TextureMemoryUsageInfo runtimeUsage, out TextureMemoryUsageInfo storageUsage)
        {
            GetMemoryUsage(out cpuUsage, delegate(Model model) { return model.CpuSize; });
            GetMemoryUsage(out gpuUsage, delegate(Model model) { return model.GpuSize; });
            GetMemoryUsage(out runtimeUsage, delegate(Model model) { return model.RuntimeSize; });
            GetMemoryUsage(out storageUsage, delegate(Model model) { return model.StorageSize; });
        }

        void GetMemoryUsage(out TextureMemoryUsageInfo usageInfo, Func<Model, int> getSize)
        {
            usageInfo = new TextureMemoryUsageInfo();

            // lookup tables to sum memory usage by texture type (Key=TextureType)
            var lookup = new Dictionary<int, TextureMemoryUsageData>();

            // collect the runtime and storage memory usage 
            foreach (var model in _items)
            {
                var size = getSize(model);
                usageInfo.TotalSize += size;

                TextureMemoryUsageData info;

                // check if usage for TextureType exists in lookup table already. if not, add it
                if (!lookup.TryGetValue(model.TextureType, out info))
                    lookup.Add(model.TextureType, info = new TextureMemoryUsageData());
                info.TextureType = (TextureUtil2.TextureType)model.TextureType;
                info.Size += size;
            }

            // add memory usage
            usageInfo.UsagePerType.AddRange(lookup.Values);

            // calc the percentage
            for (var n = 0; n < usageInfo.UsagePerType.Count; ++n)
            {
                var usage = usageInfo.UsagePerType[n];
                usage.Percentage = usage.Size / (float)usageInfo.TotalSize;
            }

            // sort runtime usage by size
            usageInfo.UsagePerType.Sort(delegate(TextureMemoryUsageData a, TextureMemoryUsageData b)
            {
                return b.Size.CompareTo(a.Size);
            });
        }

        #endregion
    }
}
