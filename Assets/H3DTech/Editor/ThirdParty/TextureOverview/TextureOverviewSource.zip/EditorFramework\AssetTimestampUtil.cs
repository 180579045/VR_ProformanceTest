﻿//---------------------------------------
// Copyright (c) 2013-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

//#define DEBUG_ASSETDATABASE3
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    /// <summary>
    /// Provides an API to read all timestamps from the file 'Library/assetDatabase3'.
    /// The origin of this hack is that there is no way to read timestamps from assets in Unity fast.
    /// AssetImporter.GetAtPath().assetTimestamp is using file io which is horribly slow!
    /// See http://console-dev.de/?p=417 for more information.
    /// </summary>
    /// <remarks>
    /// For some reason, timestamps of folders are sometimes different and don't equal the
    /// ones that AssetImporter.GetAtPath().assetTimestamp returns.
    /// </remarks>
    public static class AssetTimestampUtil
    {
        #region ReadTimestamps
        /// <summary>
        /// Reads all timestamps from the file 'Library/assetDatabase3'.
        /// </summary>
        /// <param name="timestamps">The result of the operation.</param>
        /// <returns>true on success, false otherwise.</returns>
        public static bool ReadTimestamps(out Dictionary<string, ulong> timestamps)
        {
            return ReadTimestamps(out timestamps, false);
        }

        /// <summary>
        /// Reads all timestamps from the file 'Library/assetDatabase3'.
        /// </summary>
        /// <param name="timestamps">The result of the operation.</param>
        /// <param name="debug">Whether to output lots of debug information.</param>
        /// <returns>true on success, false otherwise.</returns>
        public static bool ReadTimestamps(out Dictionary<string, ulong> timestamps, bool debug)
        {
            try
            {
                var path = EditorApplication2.LibraryPath + "/assetDatabase3";
                if (!FileUtil2.Exists(path))
                {
                    UnityEngine.Debug.LogError(string.Format("File '{0}' does not exist.", path));
                    timestamps = new Dictionary<string, ulong>();
                    return false;
                }

                UnityEngine.Profiler.BeginSample("AssetDatabase3Hack.ReadTimestamps");

                var result = ReadTimestampsImpl(path, out timestamps, debug);

                UnityEngine.Profiler.EndSample();

                return result;
            }
            catch (Exception e)
            {
                timestamps = new Dictionary<string, ulong>();
                UnityEngine.Debug.LogException(e);
                return false;
            }
        }

        static bool ReadTimestampsImpl(string path, out Dictionary<string, ulong> timestamps, bool debug)
        {
            if (debug)
                DebugLogBegin();

            timestamps = new Dictionary<string, ulong>();

            // make sure the file is big enough to be a assetDatabase3 file
            var bytes = System.IO.File.ReadAllBytes(path);
            if (bytes.Length < 0x50)
            {
                UnityEngine.Debug.LogError(string.Format("{0} not supported, seems not to be an assetDatabase3 file, because it's only {1} bytes big.", path, bytes.Length));
                return false;
            }

            DebugLog(path);

            // start reading the actual data
            var reader = new System.IO.BinaryReader(new System.IO.MemoryStream(bytes));

            // seek to the position that holds the offset to the actual timestamps table
            reader.BaseStream.Seek(12, System.IO.SeekOrigin.Begin);
            var offset = BitUtil.SwapBytes(reader.ReadUInt32());
            if (offset > bytes.Length)
            {
                UnityEngine.Debug.LogError(string.Format("offset ({0}) is larger than the actual file '{1}'", offset, path));
                return false;
            }

            DebugLog("offset: {0}", offset);

            // seek to the position where the timestamps table starts
            reader.BaseStream.Seek(offset, System.IO.SeekOrigin.Begin);
            {
                var hideFlags = reader.ReadUInt32();
                DebugLog("  hideFlags: {0} ({0:x8})", hideFlags);

                var count = reader.ReadInt32();
                DebugLog("  count: {0} ({0:x8})", count);

                // read all entries
                for (var n = 0; n < count; ++n)
                {
                    DebugLog("  entry{0} offset: {1} ({1:x8})", n, reader.BaseStream.Position);

                    // read how many characters the name contains
                    var namelength = reader.ReadInt32();
                    DebugLog("    namelength: {0} ({0:x8})", namelength);

                    // read the name characters
                    var name = System.Text.Encoding.UTF8.GetString(reader.ReadBytes(namelength), 0, namelength);
                    DebugLog("    name: {0}", name);

                    // advance the position until it is a multiple of 4
                    while ((reader.BaseStream.Position < reader.BaseStream.Length) && ((reader.BaseStream.Position % 4) != 0))
                        reader.ReadByte();

                    // read the asset timestamp
                    uint assetDate0 = reader.ReadUInt32();
                    uint assetDate1 = reader.ReadUInt32();
                    ulong assetDateRaw = ((ulong)assetDate1 << 32) | (ulong)assetDate0;

                    // read the meta file timestamp
                    uint metaDate0 = reader.ReadUInt32();
                    uint metaDate1 = reader.ReadUInt32();
                    ulong metaDateRaw = ((ulong)metaDate1 << 32) | (ulong)metaDate0;

                    DebugLog("    assetDate0: {0:x8}, assetDate1: {1:x8}, {1:x16}", assetDate0, assetDate1, assetDateRaw);
                    DebugLog("    metaDate0:  {0:x8}, metaDate1:  {1:x8}, {1:x16}", metaDate0, metaDate1, metaDateRaw);

                    ulong timestamp = 0;

                    // mac and windows interpret the timestamps differenty, figuring this
                    // out of a painful trial&error session.
                    // basically unity uses the timestamp that is newer, either from the asset of the meta file
                    if (Application.platform == RuntimePlatform.WindowsEditor)
                    {
                        if (assetDateRaw > metaDateRaw)
                            timestamp = ((ulong)assetDate1 << 16) | ((ulong)assetDate0 >> 16);
                        else
                            timestamp = ((ulong)metaDate1 << 16) | ((ulong)metaDate0 >> 16);
                    }
                    else
                    {
                        if (assetDateRaw > metaDateRaw)
                            timestamp = ((ulong)assetDate0 << 32) | ((ulong)assetDate1 << 16);
                        else
                            timestamp = ((ulong)metaDate0 << 32) | ((ulong)metaDate1 << 16);
                    }

                    DebugLog("    timeStamp: {0:x}", timestamp);

                    // add the timestamp to our lookup table
                    // we check if the asset is located inside Assets/, because we're only interested
                    // in those and converting a non-assets/ path to a guid shows a warning.
                    if (name != null && name.StartsWith("Assets/", StringComparison.OrdinalIgnoreCase))
                    {
                        var guid = AssetDatabase.AssetPathToGUID(name);
                        DebugLog("    guid: {0}", guid);
                        timestamps[guid] = timestamp;
                    }

#if DEBUG_ASSETDATABASE3
                    if (debug)
                    {
                        if ((n % 20) == 0)
                        {
                            var progress = n / (float)count;
                            var text = string.Format("[{1} remaining] {0}", FileUtil2.GetFileName(path), count - n - 1);
                            if (EditorUtility.DisplayCancelableProgressBar("Checking Timestamps", text, progress))
                                break;
                        }

                        var importer = AssetImporter.GetAtPath(name);
                        if (importer != null)
                        {
                            DebugLog("    timeStamp: {0:x} (unity)", importer.assetTimeStamp);
                            if (timestamp != importer.assetTimeStamp)
                                DebugLog("    timeStamp mismatch");
                        }
                        else
                            DebugLog("    imported not found");
                    }
#endif // DEBUG_ASSETDATABASE3
                }
            }

            if (debug)
                DebugLogEnd();

            return true;
        }
        #endregion

        #region ContainsText
        /// <summary>
        /// Checks whether the specified text (case ignored) is located in the buffer at the specified index.
        /// </summary>
        /// <param name="buffer">The buffer</param>
        /// <param name="index">The index into the buffer</param>
        /// <param name="text">The text to check</param>
        /// <returns>true when it contains the text, false otherwise.</returns>
        static bool ContainsText(byte[] buffer, int index, string text)
        {
            for (var n = 0; n < text.Length; ++n)
            {
                var c = char.ToLower((char)buffer[index + n]);

                if (c != char.ToLower(text[n]))
                    return false;
            }
            return true;
        }
        #endregion

        #region Debugging
        static System.Text.StringBuilder _debugLog;

        [System.Diagnostics.Conditional("DEBUG_ASSETDATABASE3")]
        static void DebugLogBegin()
        {
            _debugLog = new System.Text.StringBuilder(1024 * 8);
        }

        [System.Diagnostics.Conditional("DEBUG_ASSETDATABASE3")]
        static void DebugLog(string format, params object[] args)
        {
            if (null == _debugLog)
                return;

            var text = string.Format(format, args);
            _debugLog.AppendLine(text);
        }

        [System.Diagnostics.Conditional("DEBUG_ASSETDATABASE3")]
        static void DebugLogEnd()
        {
            var debugtxt = FileUtil.GetUniqueTempPathInProject() + ".txt";
            UnityEngine.Debug.Log("Creating file '" + debugtxt + "'");
            System.IO.File.WriteAllText(debugtxt, _debugLog.ToString());
            EditorUtility.OpenWithDefaultApp(debugtxt);
            EditorUtility.ClearProgressBar();

            _debugLog = null;
        }
        #endregion
    }
}
