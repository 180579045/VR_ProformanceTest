﻿//---------------------------------------
// Copyright (c) 2013-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.IO;

namespace EditorFramework
{
    /// <summary>
    /// BinarySerializer is a helper to serialize and deserialize data.
    /// Serializing and Deserializing is utilized using the same methods,
    /// there is no need to write special Read and Write code.
    /// </summary>
    public class BinarySerializer
    {
        readonly BinaryReader _reader;
        readonly BinaryWriter _writer;

        /// <summary>
        /// Indicates whether BinarySerializer has been initialized using a BinaryReader.
        /// </summary>
        public bool IsReader
        {
            get
            {
                return _reader != null;
            }
        }

        /// <summary>
        /// Indicates whether BinarySerializer has been initialized using a BinaryWriter.
        /// </summary>
        public bool IsWriter
        {
            get
            {
                return _writer != null;
            }
        }

        /// <summary>
        /// Initializes a new instance to read data.
        /// </summary>
        /// <param name="reader">The BinaryReader</param>
        public BinarySerializer(BinaryReader reader)
        {
            _reader = reader;
        }

        /// <summary>
        /// Initializes a new instance to write data.
        /// </summary>
        /// <param name="reader">The BinaryWriter</param>
        public BinarySerializer(BinaryWriter writer)
        {
            _writer = writer;
        }

        /// <summary>
        /// Reads or writes the specified value to the underlaying stream.
        /// </summary>
        /// <param name="value">The value to read or write.</param>
        /// <remarks>
        /// A null value is actually written as an empty string.
        /// </remarks>
        public void Serialize(ref string value)
        {
            if (_reader != null)
                value = _reader.ReadString();
            else
                _writer.Write(value ?? "");
        }

        /// <summary>
        /// Reads or writes the specified value to the underlaying stream.
        /// </summary>
        /// <param name="value">The value to read or write.</param>
        public void Serialize(ref bool value)
        {
            if (_reader != null)
                value = _reader.ReadBoolean();
            else
                _writer.Write(value);
        }

        /// <summary>
        /// Reads or writes the specified value to the underlaying stream.
        /// </summary>
        /// <param name="value">The value to read or write.</param>
        public void Serialize(ref char value)
        {
            if (_reader != null)
                value = _reader.ReadChar();
            else
                _writer.Write(value);
        }

        /// <summary>
        /// Reads or writes the specified value to the underlaying stream.
        /// </summary>
        /// <param name="value">The value to read or write.</param>
        public void Serialize(ref byte value)
        {
            if (_reader != null)
                value = _reader.ReadByte();
            else
                _writer.Write(value);
        }

        /// <summary>
        /// Reads or writes the specified value to the underlaying stream.
        /// </summary>
        /// <param name="value">The value to read or write.</param>
        public void Serialize(ref Int16 value)
        {
            if (_reader != null)
                value = _reader.ReadInt16();
            else
                _writer.Write(value);
        }

        /// <summary>
        /// Reads or writes the specified value to the underlaying stream.
        /// </summary>
        /// <param name="value">The value to read or write.</param>
        public void Serialize(ref UInt16 value)
        {
            if (_reader != null)
                value = _reader.ReadUInt16();
            else
                _writer.Write(value);
        }

        /// <summary>
        /// Reads or writes the specified value to the underlaying stream.
        /// </summary>
        /// <param name="value">The value to read or write.</param>
        public void Serialize(ref Int32 value)
        {
            if (_reader != null)
                value = _reader.ReadInt32();
            else
                _writer.Write(value);
        }

        /// <summary>
        /// Reads or writes the specified value to the underlaying stream.
        /// </summary>
        /// <param name="value">The value to read or write.</param>
        public void Serialize(ref UInt32 value)
        {
            if (_reader != null)
                value = _reader.ReadUInt32();
            else
                _writer.Write(value);
        }

        /// <summary>
        /// Reads or writes the specified value to the underlaying stream.
        /// </summary>
        /// <param name="value">The value to read or write.</param>
        public void Serialize(ref Single value)
        {
            if (_reader != null)
                value = _reader.ReadSingle();
            else
                _writer.Write(value);
        }

        /// <summary>
        /// Reads or writes the specified value to the underlaying stream.
        /// </summary>
        /// <param name="value">The value to read or write.</param>
        public void Serialize(ref Int64 value)
        {
            if (_reader != null)
                value = _reader.ReadInt64();
            else
                _writer.Write(value);
        }

        /// <summary>
        /// Reads or writes the specified value to the underlaying stream.
        /// </summary>
        /// <param name="value">The value to read or write.</param>
        public void Serialize(ref UInt64 value)
        {
            if (_reader != null)
                value = _reader.ReadUInt64();
            else
                _writer.Write(value);
        }

        /// <summary>
        /// Reads or writes the specified value to the underlaying stream.
        /// </summary>
        /// <typeparam name="T">The enum type</typeparam>
        /// <param name="value">The value to read or write.</param>
        public void SerializeEnum<T>(ref T value)
        {
            if (_reader != null)
            {
                Int32 ivalue = 0;
                Serialize(ref ivalue);
                value = (T)(object)ivalue;
            }
            else
            {
                Int32 ivalue = Convert.ToInt32(value);
                Serialize(ref ivalue);
            }
        }
    }
}
