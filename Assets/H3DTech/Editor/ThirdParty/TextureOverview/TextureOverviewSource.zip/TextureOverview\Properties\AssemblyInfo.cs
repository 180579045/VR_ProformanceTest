﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using UnityEngine;

[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Peter Schraut")]
[assembly: AssemblyProduct("TextureOverview")]
[assembly: AssemblyCopyright("Copyright 2011-2014 Peter Schraut")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.*")]

#if UNITY_5
[assembly: AssemblyTitle("Texture Overview for Unity 5")]
[assembly: Guid("ab4681f7-37ea-44f2-9a7e-7572fa544cec")]
[assembly: AssemblyIsEditorAssembly]
#else
[assembly: AssemblyTitle("TextureOverview for Unity 4")]
[assembly: Guid("eec47972-a007-472a-9f94-ee246a92b692")]
#endif
